package com.ms;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CheckCreditCard {
		public static void main(String[] args){
				int [] numbers={4,9,0,1,2,5,0,2,4,0,5,5,5,3,6};
				verify(numbers);
		}
		
		public static String  verify(int [] cardNumber){
				
				int len =cardNumber.length;
				System.out.println(cardNumber[len-1]);
				int LastDigit=cardNumber[len-1];
				Map<Integer,Integer> reverse=new HashMap<>();
				List<Integer> reverserList=new ArrayList<>();
				for(int i=len-1;i>=0;i--){
						System.out.print(cardNumber[i]);
						reverserList.add(cardNumber[i]);
				}
				List<Integer> doubleEvenNumber=new ArrayList<>();
				for(int numnber:reverserList){
						if(numnber%2==0){
								doubleEvenNumber.add(numnber*2);
						}else {
								doubleEvenNumber.add(numnber);
						}
						
				}
				System.out.println("");
				List<Integer> doubleEvenNumberS=new ArrayList<>();
				for(int numnber:doubleEvenNumber){
						if(numnber%2==0){
								doubleEvenNumberS.add(numnber-9)	;
						}else{
								doubleEvenNumberS.add(numnber);
						}
				}
				int sum=0;
				for(int numnber:doubleEvenNumberS){
						sum=sum+numnber;
				}
				System.out.println(sum);
				
				return null;
		}
		
}
