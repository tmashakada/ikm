package com.ms;


import java.util.Arrays;
import org.apache.commons.lang3.StringUtils;

public class TestRe {
		static final String FIELD_72_CODE_RECEIVE_RETURN_OF_FUNDS_WITH_SAMOS = "/REC/DTROF";
		static final String FIELD_72_CODE_RETURN = "/RETN/";
		static final String FIELD_72_CODE_REJECT = "/REJT/";//Using 72 because of MT format
		public static final String CHRG_BR_OPEN_TAG = "<ChrgBr>";
		public static final String CHRG_BR_CLOSE_TAG = "</ChrgBr>";
		public  static final String COMPLIANCE_TYPE="SPOT2";
		public static final String VALUETO_REPLACE = "valuetoReplace";
		public  static final String 		COMPLIANCE_DATE="";
		
		public static void main(String[] args) {
				
				String myStr = "Hello planet earth,<ChrgBr>SHA</ChrgBr> you are a great planet.";
				String tag20="OT22055ZA0079938";
				String defaultCharge="CRED";
				System.out.println(getChrgBr(tag20,defaultCharge));
				String tagValue72="/REC/DTCUS";
				System.out.println(isITForwardFunding(tagValue72));
				System.out.println(isITTForwardFunds2(tagValue72));
				System.out.println("======================================");
	
				System.out.println(isITTForwardFunds(tagValue72));
				System.out.println(isChrgBrEmpty(myStr));
				if (isITTForwardFunds(tagValue72) && isChrgBrEmpty(myStr)) {
						System.out.println("Replace now");
				}else{
						System.out.println("nnnnnnnnnnnnnnnnnnnn");
				}
				System.out.println("nnnnnnnnnnnnnnnnnnnn" +	checkComplianceDate());
				int[] numbers={6,8,7,14,21,13,85,41,45};
			int max=	findMax(numbers);
				System.out.println("MAX  " +	max);
		//		protected static StringBuilder mapForZDS(StringBuilder sbMxMessage, JSONObject mtMessage, String tagValue72, String tag20)
		//		replaceTagValues(StringBuilder sbSource, StringBuilder sbTarget, String tag20, String sourceTagName, String valueToReplace);
				StringBuilder  sbMxMessage=new StringBuilder();
				sbMxMessage.append(myStr );
				StringBuilder result=	replaceTagValues(sbMxMessage, sbMxMessage, tag20, "ChrgBr", "SLEV");
				System.out.println("Result  " +	result);
				
				
		}
		//F23B
		// <ChrgBr>CRED</ChrgBr>
		public static String getChrgBr(String tag20, String defaultChrgBr) {
				final String strTag20 = tag20.substring(0, 2);
				
				return !strTag20.equalsIgnoreCase("IT") ? "SLEV" : defaultChrgBr;
				
		}
		
		
		public static boolean isITTForwardFunds4(String tagValue72) {
				
				return !tagValue72.contains(FIELD_72_CODE_RECEIVE_RETURN_OF_FUNDS_WITH_SAMOS) && !tagValue72.contains(
								FIELD_72_CODE_RETURN) && !tagValue72.contains(FIELD_72_CODE_REJECT);
		}
		
		public static boolean isITTForwardFunds3(String tagValue72) {
				return Arrays.asList(
								FIELD_72_CODE_RECEIVE_RETURN_OF_FUNDS_WITH_SAMOS,
								FIELD_72_CODE_RETURN,
								FIELD_72_CODE_REJECT).stream().noneMatch(tagValue72::contains);
		}
		public static boolean isITTForwardFunds7(String tagValue72){
				
				if ((tagValue72.contains(FIELD_72_CODE_RECEIVE_RETURN_OF_FUNDS_WITH_SAMOS) || tagValue72.contains(FIELD_72_CODE_RETURN) || tagValue72.contains(FIELD_72_CODE_REJECT))) {
						return false;
				}
				return true;
		}
		
		public static boolean isITTForwardFunds2(String tagValue72){
				
				return !tagValue72.contains(FIELD_72_CODE_RECEIVE_RETURN_OF_FUNDS_WITH_SAMOS) && !tagValue72.contains(
								FIELD_72_CODE_RETURN) && !tagValue72.contains(FIELD_72_CODE_REJECT);
		}
		public  void itt(String tag20,String tagValue72) {
				if ("OT".equalsIgnoreCase(tag20.substring(0, 2))) {
					System.out.println("Replace");
				}
		}
		public static boolean  isITForwardFunding(String tagValue72){
				
				if ((tagValue72.contains(FIELD_72_CODE_RECEIVE_RETURN_OF_FUNDS_WITH_SAMOS) || tagValue72.contains(FIELD_72_CODE_RETURN) || tagValue72.contains(FIELD_72_CODE_REJECT))) {
						return false;
				}
				return true;
		}
		public static boolean isChrgBrEmpty(String myStr) {
				return StringUtils.isEmpty(StringUtils.substringBetween(myStr, CHRG_BR_OPEN_TAG, CHRG_BR_CLOSE_TAG).trim());
				
		}
		
		public static boolean isITTForwardFunds(String tagValue72) {
				return Arrays.asList(
								FIELD_72_CODE_RECEIVE_RETURN_OF_FUNDS_WITH_SAMOS,
								FIELD_72_CODE_RETURN,
								FIELD_72_CODE_REJECT
				).stream().noneMatch(tagValue72::contains);
		}
		
		public static boolean checkComplianceDate() {
				try{
						if((COMPLIANCE_TYPE=="SPOT" || COMPLIANCE_TYPE=="HEDGE")  && COMPLIANCE_DATE==""){
								return false;
						}
						return true;
				}catch (Exception e){
				
				}
				
				return false;
		}
		public static int findMax(int [] numbers){
				int max=0;
				for(int i=0;i<numbers.length;i++){
						if(numbers[i]>max){
								max=numbers[i];
						}
				}
				return max;
		}
		protected static StringBuilder replaceTagValues(StringBuilder sbSource, StringBuilder sbTarget, String tag20, String sourceTagName, String valueToReplace) {
				//This method finds sourceTagName tag value from sbSource, then replace it in the target
				//Ideally Source and Destination should be same string as we are not checking nullCheck on target. To do if both are different.
				int sourceTagStartPos = sbSource.indexOf("<" + sourceTagName + ">") + sourceTagName.length() + 2;
				System.out.println("ppppppppppp 1" +sourceTagName );
				System.out.println("ppppppppppp 1" +sourceTagName.length() );
				System.out.println("ppppppppppp 2" +sbSource.indexOf("<" + sourceTagName + ">"));
		 	System.out.println("ppppppppppp 3" +sourceTagStartPos);
				int sourceTagEndPos = sbSource.indexOf("</" + sourceTagName + ">", sourceTagStartPos + 1);
				System.out.println( "replaceTagValues() tag20:" + tag20 + ", sourceTagName:" + sourceTagName + ", " + VALUETO_REPLACE + ":" + valueToReplace);
				System.out.println("ppppppppppp  2" +sourceTagEndPos);
				if (sourceTagEndPos > 0) {
						sbTarget.replace(sourceTagStartPos, sourceTagEndPos, valueToReplace);
				}
				return sbTarget;
		}
	
		
		
}
