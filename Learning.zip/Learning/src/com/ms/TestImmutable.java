package com.ms;

public class TestImmutable {
		
		public  static void main(String [] args){
				// create object of Immutable
				Immutable obj = new Immutable("Programiz", 2011);
				
				System.out.println("Name: " + obj.getName());
				System.out.println( isEven(2));
		}
		private static boolean  isEven(int num){
				if(num%2==0){
						return true;
				}
				return false;
		}
}
