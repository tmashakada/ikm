package com.ms;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;

public class MergeNames {
    
    public static String[] uniqueNames2(String[] names1, String[] names2) {

        HashMap<Integer,String> mapUnigue=new HashMap<>();
        int length =names1.length + names2.length;

       String[] result = new String[length];
        int pos = 0;
        for (String element : names1) {
            result[pos] = element;
            pos++;
        }

        for (String element : names2) {
            result[pos] = element;
            pos++;
        }

        System.out.println(Arrays.toString(result));
        return result;
        //throw new UnsupportedOperationException("Waiting to be implemented.");
    }
  public static String[] uniqueNames(String[] names1, String[] names2) {
    HashSet<String> hs = new HashSet<String>();
    for (String element : names1) {
     hs.add(element);
    }
    for (String element : names2) {
      hs.add(element);
    }
    String arr[] = new String[hs.size()];

    // toArray() method converts the set to array
   return hs.toArray(arr);
   // return (String[]) hs.toArray();
  }
  public static Integer []uniqueNumbers(int[] n){
      HashSet<Integer>  hs=new HashSet<>();
      for (int m:n){
        hs.add(m);
      }
    Integer arr[]=new Integer[hs.size()];
    System.out.println(hs);
     return hs.toArray(arr);
  }

    public static void main(String[] args) {
        String[] names1 = new String[] {"Ava", "Emma", "Olivia"};
        String[] names2 = new String[] {"Olivia", "Sophia", "Emma"};
        System.out.println(String.join(", ", MergeNames.uniqueNames(names1, names2))); // should print Ava, Emma, Olivia, Sophia
       int[] m=new int[]{1,5,1,2,3,2,5,7,4,3};
      //MergeNames.uniqueNumbers(m).forEach(System.out::println);
      System.out.println(MergeNames.uniqueNumbers(m));
      Arrays.asList(MergeNames.uniqueNumbers(m)).stream().forEach(System.out::println);

    }
}