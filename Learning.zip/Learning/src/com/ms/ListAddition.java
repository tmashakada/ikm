package com.ms;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class ListAddition {
		
		public static void main(String [] args){
				int[] l = null;
				System.out.println(list_addSet(17, l));
		}
		// Time complexity: O(n)
		public static boolean list_add(int k, int[] list){
				Map<Integer,Integer> numMap=new HashMap<>();
				
				for(int i=0;i<list.length;i++){
						
						int complement=k-list[i];
						if(numMap.containsKey(complement)){
								return  true;
						}else{
								numMap.put(list[i], i);
						}
				}
				return false;
		}
		
		public static boolean list_addSet(int k, int[] list){

				Set<Integer> numMap=new HashSet<>();
				
				for(int i=0;i<list.length;i++){
						
						int complement=k-list[i];
						if(numMap.contains(complement)){
								return  true;
						}else{
								numMap.add(list[i]);
						}
				}
				return false;
		}
}
