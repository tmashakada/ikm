package com.ms;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

public class TwoSum {
		
		/**1.Initial an empty HashMap
				 2.Iterate over the elements array nums
				 3.For every element in the array
				   check if compliment (target-element ) exists in the map or not
				   if the compliment  exists then return the indices of current element and compliment
				  Otherwise add the element to the map and move to the next iteration*
			*
			* @param nums
			* @param target
			* @return
			*/
		public static int[]  findTwoSum(int [] nums, int target){
				
				
				Map<Integer,Integer> numMap=new HashMap<>();
				for(int i=0;i<nums.length;i++){
						int complement=target=nums[i];
						if(numMap.containsKey(complement)){
								 return new int[]{numMap.get(complement),i};
						}else{
								 numMap.put(nums[i],i);
						}
						
				}
				
				return new int[]{};
		}
		public static int[] findTwoSumIndices2(int[] nums, int target) {
				/**
					* This problem was recently asked by Google.
					*
					* Given a list of numbers and a number k, return whether any two numbers from
					* the list add up to k. For example, given [10, 15, 3, 7] and k of 17, return
					* true since 10 + 7 is 17.
					*
					* Bonus: Can you do this in one pass?
					*
					* @author antonioalanxs
					*/
				
				
				//int [] nums = {11, 2, 7, 15};
				// 7
				//  Map<Integer, Integer> numMap = new HashMap<>();
				HashSet<Integer> numMap=new HashSet<>();
				for (int i :nums) {
						int complement = target - i;
						//System.out.println(complement +" "+i);
						if (numMap.contains(complement)) {
								return new int[] { complement, i };
						} else {
								numMap.add(i);
						}
				}
				return new int[] {};
		}
		
}
