package com.ms;

import java.util.HashSet;
import java.util.Set;

public class MissingNumberSolution {
		public  static void main(String [] args){
				int [] nums={4,5,1,2,6};
				int number= missingNumber( nums);
				System.out.println(number);
		}
		
		public static   int missingNumber(int [] nums){
				int size = nums.length;
				Set<Integer> fullNumbers = new HashSet<>();
				for (int number : nums) {
						fullNumbers.add(number);
				}
				for (int i = 1; i < size; i++) {
						if (!fullNumbers.contains(i)) {
								return i;
						}
				}
				return size;
		}
		
}
