package com.ms;

import java.time.DayOfWeek;
import java.time.LocalDate;
import org.apache.commons.lang3.StringUtils;

public class Switch {
		
		public static void main(String[] args) {
				DayOfWeek dayOfWeek = LocalDate.now().getDayOfWeek();
				boolean freeDay = switch (dayOfWeek) {
						case MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY -> false;
						case SATURDAY, SUNDAY -> true;
				};
				System.out.println(freeDay);
				
				String myStr = "Hello planet earth,<ChrgBr> </ChrgBr> you are a great planet.";
				System.out.println(myStr.indexOf("<ChrgBr>"));
				System.out.println(myStr.indexOf("</ChrgBr>"));
				System.out.println(myStr.substring(myStr.indexOf("<ChrgBr>")+8,myStr.indexOf("</ChrgBr>")));
				System.out.println(isChrgBrEmpty(myStr));
			String nn=	StringUtils.substringBetween(myStr,"<ChrgBr>","</ChrgBr>");
			System.out.println(nn);
		}
		public static boolean  isChrgBrEmpty(String myStr){
		
				return StringUtils.isEmpty(StringUtils.substringBetween(myStr,"<ChrgBr>","</ChrgBr>").trim());
	
		}

}
