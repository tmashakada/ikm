package com.ms;

public class ReverseWord {
		
		public static  void main(String [] args){
			
			String bb=	reverse("I love you");
				System.out.println(bb);
		}
		public static String reverse(String words){
				//Split the words using space into array
				String [] splitted= words.split("\\s");
				//Initial Object String Buider
				StringBuilder sb=new StringBuilder();
				///Get the Lenght  of the splitted String  array
				int len=splitted.length;
				//Iterate  throught the splitted stringb array starting from the last item in an array adding it to the stringBuilder
				// object going  back wards
				for( int i=(len-1);i>=0;i--){
						sb.append(splitted[i]);
						sb.append(" ");
				}
				return sb.toString();
		}
		
}
