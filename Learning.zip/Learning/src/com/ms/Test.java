package com.ms;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Test {
  public static final String CHOICE_57_AD = "Choice_57ABCD";
  public static final String CHOICE_52_AD = "Choice_52AD";
  
  
  public static void main(String[] args) {
    int number= (int)(Math.random()*900000)+100000;
    String msg="{B1:{A:\"F\",S:\"01\",BIC:\"SBZAZWJ0XXXX\",Session:\"2939\",Seq:\"012589\"},B2:{IO:\"I\",MT:\"103\",BIC:\"FIRNZAJ0XXXX\",Priority:\"N\"},B3:{103:\"ZDS\",108:\"1645697968330170\",111:\"001\",121:\"d2cbda37-0264-47b8-b17e-bc27fa4c7020\"},_mt_full_:\"MT103\",TEXT:{F20:\"OT22055ZA0079938\",F23B:\"CRED\",F32A:{Date:\"220224\",Currency:\"ZAR\",Amount:\"709029,89\"},F33B:{Currency:\"ZAR\",Amount:\"709029,89\"},Choice_50AFK:{F50F:{PartyIdentifier:\"/0000000000079057\",NameAndAddress:\"1/TELKOM SA SOC LTD\\r\\n2/152 PROES STREET\\r\\n2/TELKOM TOWERS NORTH\\r\\n3/ZA/SOUTH AFRICA\",@nm:\"F50F\"}},Choice_52AD:{F52A:{IdentifierCode:\"SBZAZWJ0XXX\",@nm:\"F52A\"}},Choice_57ABCD:{F57A:{IdentifierCode:\"FIRNZAJ0XXX\",@nm:\"F57A\"}},Choice_59AF:{F59F:{Account:\"62414561911\",NameAndAddressDetails:\"1/ZWAKI PROJECTS AND CONSULTING (PT\\r\\n1/Y) LTD.\\r\\n2/UNIT B25 CO.SPACE\\r\\n3/ZA/SOUTH AFRICA\",@nm:\"F59F\"}},F70:\"3078\",F71A:\"SHA\",Loop3:[{F71F:{Currency:\"ZAR\",Amount:\"0,00\"}}],F72:\"/REC/DTCUS\"},bizsvc:\"swift.cbprplus.02\"}";
    String lastpart=new SimpleDateFormat("ss").format(Calendar.getInstance().getTime());
    System.out.println(number+""+lastpart);
   // .substring(4, 6);
  
    String tag57 = getTag57(msg);
    System.out.println( "GGGGGGGGGGGGGGGGGGGG>>>>>> MMM   "+ tag57.startsWith("ZA", 4) );
   // System.out.println(tag57.substring(4,6) );
    String tag52 = getTag52(msg);
 //   System.out.println(tag52.substring(4,6) );
    System.out.println(tag52 );
    if (!tag57.isEmpty() && !tag52.isEmpty()) {
      System.out.println("nnnnnnnnnnnnnn");
      if (tag57.startsWith("ZA", 4) && tag52.startsWith("ZA", 4)) {
        System.out.println("Override ");
      }
    }
    //if (tag57.substring(4, 6).equals(tag52.substring(4, 6))  && tag52.substring(4, 6)=="ZA"){
  }
  public static void main2(String[] args) {
    int number= (int)(Math.random()*900000)+100000;
    String msg="{B1:{A:\"F\",S:\"01\",BIC:\"SBZAZWJ0XXXX\",Session:\"2939\",Seq:\"012589\"},B2:{IO:\"I\",MT:\"103\",BIC:\"FIRNZAJ0XXXX\",Priority:\"N\"},B3:{103:\"ZDS\",108:\"1645697968330170\",111:\"001\",121:\"d2cbda37-0264-47b8-b17e-bc27fa4c7020\"},_mt_full_:\"MT103\",TEXT:{F20:\"OT22055ZA0079938\",F23B:\"CRED\",F32A:{Date:\"220224\",Currency:\"ZAR\",Amount:\"709029,89\"},F33B:{Currency:\"ZAR\",Amount:\"709029,89\"},Choice_50AFK:{F50F:{PartyIdentifier:\"/0000000000079057\",NameAndAddress:\"1/TELKOM SA SOC LTD\\r\\n2/152 PROES STREET\\r\\n2/TELKOM TOWERS NORTH\\r\\n3/ZA/SOUTH AFRICA\",@nm:\"F50F\"}},Choice_52AD:{F52A:{IdentifierCode:\"SBZAZWJ0XXX\",@nm:\"F52A\"}},Choice_57ABCD:{F57A:{IdentifierCode:\"FIRNZAJ0XXX\",@nm:\"F57A\"}},Choice_59AF:{F59F:{Account:\"62414561911\",NameAndAddressDetails:\"1/ZWAKI PROJECTS AND CONSULTING (PT\\r\\n1/Y) LTD.\\r\\n2/UNIT B25 CO.SPACE\\r\\n3/ZA/SOUTH AFRICA\",@nm:\"F59F\"}},F70:\"3078\",F71A:\"SHA\",Loop3:[{F71F:{Currency:\"ZAR\",Amount:\"0,00\"}}],F72:\"/REC/DTCUS\"},bizsvc:\"swift.cbprplus.02\"}";
    String lastpart=new SimpleDateFormat("ss").format(Calendar.getInstance().getTime());
    System.out.println(number+""+lastpart);
    // .substring(4, 6);
    
    String tag57 = getTag57(msg);
    System.out.println(tag57 );
//    System.out.println(tag57.substring(4,6) );
    String tag52 = getTag52(msg);
    //   System.out.println(tag52.substring(4,6) );
    System.out.println(tag52 );
    if (!tag57.isEmpty() && !tag52.isEmpty()) {
      System.out.println("nnnnnnnnnnnnnn");
      if (tag57.substring(4, 6).equals("ZA") && tag52.substring(4, 6).equals("ZA")){
        System.out.println("Override ");
      }
    }
    //if (tag57.substring(4, 6).equals(tag52.substring(4, 6))  && tag52.substring(4, 6)=="ZA"){
  }
  public static String  getTag57(String msg){
    String tag57;
    if(msg.contains(CHOICE_57_AD)){
      tag57="";
   
    }else{
      tag57="";
    }
    return tag57;
  }
  public static String  getTag52(String msg){
    String tag57;
    if(msg.contains(CHOICE_52_AD)){
      tag57="SBZAZAJ0XXX";
    
    }else{
      tag57="";
    }
    return tag57;
  }
  
}
