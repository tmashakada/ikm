package com.learning;

import java.util.List;


import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

@XStreamAlias("bop")
public class Bop extends BaseObject {

    private BopHeader bopHeader;

    @XStreamImplicit
    @XStreamAlias("bopDetails")
    private List<BopDetails> bopDetails;

    public BopHeader getBopHeader() {
        return bopHeader;
    }

    public void setBopHeader(BopHeader bopHeader) {
        this.bopHeader = bopHeader;
    }

    public List<BopDetails> getBopDetails() {
        return bopDetails;
    }

    public void setBopDetails(List<BopDetails> bopDetails) {
        this.bopDetails = bopDetails;
    }



}
