package com.learning;



import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

/**
 *
 * @author Herman Sheppard
 *
 * XStream object wrapping for XML received from nBol.
 *
 */

public class NBolXMLProcessingOption extends BaseObject{

    private static final long serialVersionUID = -3045472723367491200L;

    @XStreamAlias("processingName")
    private String processingName;

    @XStreamAlias("processingValue")
    private String processingValue;

    public void setProcessingName(String processingName) {
        this.processingName = processingName;
    }

    public String getProcessingName() {
        return processingName;
    }

    public void setProcessingValue(String processingValue) {
        this.processingValue = processingValue;
    }

    public String getProcessingValue() {
        return processingValue;
    }
}
