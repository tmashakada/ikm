package com.learning;


import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

public class TransactionProcessingOption extends BaseObject{

    @XStreamAlias("ProcessingName")
    private String processingName;

    @XStreamAlias("ProcessingValue")
    private String processingValue;

    public void setProcessingName(String processingName) {
        this.processingName = processingName;
    }

    public String getProcessingName() {
        return processingName;
    }

    public void setProcessingValue(String processingValue) {
        this.processingValue = processingValue;
    }

    public String getProcessingValue() {
        return processingValue;
    }
}
