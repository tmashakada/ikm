package com.learning;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("payload")
public class ResponsePayloadOnlyError extends BaseObject  {

    private static final long serialVersionUID = 4570394985089966190L;

    private GenericResponseError error;
    private String status;
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public GenericResponseError getError() {
        return error;
    }

    public void setError(GenericResponseError error) {
        this.error = error;
    }
}

