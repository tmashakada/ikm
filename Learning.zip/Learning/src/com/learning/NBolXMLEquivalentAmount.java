package com.learning;


import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("EqvtAmt")
public class NBolXMLEquivalentAmount extends BaseObject{

    private static final long serialVersionUID = -3045472820367491210L;

    @XStreamAlias("Amt")
    private String amount;

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getAmount() {
        return amount;
    }
}
