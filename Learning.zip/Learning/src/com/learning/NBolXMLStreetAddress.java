package com.learning;


import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("Address")
public class NBolXMLStreetAddress extends BaseObject{

    @XStreamAlias("StreetAddressLine1")
    private String line1;

    @XStreamAlias("StreetAddressLine2")
    private String line2;

    @XStreamAlias("StreetSuburb")
    private String suburb;

    @XStreamAlias("StreetProvince")
    private String province;

    @XStreamAlias("StreetPostalCode")
    private String postalCode;

    public String getLine1() {
        return line1;
    }

    public void setLine1(String line1) {
        this.line1 = line1;
    }

    public String getLine2() {
        return line2;
    }

    public void setLine2(String line2) {
        this.line2 = line2;
    }

    public String getSuburb() {
        return suburb;
    }

    public void setSuburb(String suburb) {
        this.suburb = suburb;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }



}
