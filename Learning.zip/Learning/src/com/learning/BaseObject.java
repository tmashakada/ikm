package com.learning;



import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Collection;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;


/**
 * Base class for Model objects.  This is basically for the toString method.
 *
 * @author DudleyB
 */
public class BaseObject{

    public String getStr(String value){
        return StringUtils.isBlank(value) ? "" : value.trim();
    }

    public String toString() {
        return ToStringBuilder.reflectionToString(this,
                ToStringStyle.MULTI_LINE_STYLE);
    }

    public void ensureDefaultValues() {
        ensureDefaultValues("");
    }

    public void ensureDefaultValues(String defaultValue, String... searches){
        final Method[] methods = this.getClass().getMethods();

        try {
            for (Method method : methods) {
                if (StringUtils.startsWith(method.getName(), "set")) {
                    final String getterMethodName = StringUtils.replace(method.getName(), "set", "get");
                    final Method getter = this.getClass().getMethod(getterMethodName);

                    final Object object = getter.invoke(this);

                    if (object == null && (getter.getReturnType().isPrimitive() || getter.getReturnType().isInstance(new String()))){
                        method.invoke(this, defaultValue);
                    } else if (object != null && getter.getReturnType().isInstance(new String()) && searches.length > 0 && Arrays.asList(searches).contains(object)) {
                        method.invoke(this, defaultValue);
                    } else if (object != null && object instanceof BaseObject){
                        ((BaseObject) object).ensureDefaultValues();
                    } else if (object != null && object instanceof Collection<?>) {
                        for(Object child : (Collection<?>) object) {
                            ((BaseObject) child).ensureDefaultValues();
                        }
                    }
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
