package com.learning;


import com.thoughtworks.xstream.annotations.XStreamAlias;

public class NBolXMLDocument  extends BaseObject{
    @XStreamAlias("DocId")
    private String documentId;

    @XStreamAlias("DocNm")
    private String documentName;

    @XStreamAlias("DocDesc")
    private String documentDescription;

    @XStreamAlias("Content")
    private String content;

    @XStreamAlias("MIMEType")
    private String mimeType;

    @XStreamAlias("ComprssCriteria")
    private String compressCriteria;

    public String getDocumentId() {
        return documentId;
    }

    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }

    public String getDocumentName() {
        return documentName;
    }

    public void setDocumentName(String documentName) {
        this.documentName = documentName;
    }

    public String getDocumentDescription() {
        return documentDescription;
    }

    public void setDocumentDescription(String documentDescription) {
        this.documentDescription = documentDescription;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getMimeType() {
        return mimeType;
    }

    public void setMimeType(String mimeType) {
        this.mimeType = mimeType;
    }

    public String getCompressCriteria() {
        return compressCriteria;
    }

    public void setCompressCriteria(String compressCriteria) {
        this.compressCriteria = compressCriteria;
    }


}
