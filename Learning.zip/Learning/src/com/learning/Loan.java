package com.learning;

import com.thoughtworks.xstream.annotations.XStreamAlias;

public class Loan {
    @XStreamAlias("tenor")
    public String tenor;
    @XStreamAlias("rate")
    public String rate;
    @XStreamAlias("plusMinus")
    public String plusMinus;
    @XStreamAlias("index")
    public String index;
    @XStreamAlias("maturityDate")
    public String maturityDate;
    public String reference;

    public String getTenor() {
        return tenor;
    }

    public void setTenor(String tenor) {
        this.tenor = tenor;
    }

    public String getRate() {
        return rate;
    }

    public void setRate(String rate) {
        this.rate = rate;
    }

    public String getPlusMinus() {
        return plusMinus;
    }

    public void setPlusMinus(String plusMinus) {
        this.plusMinus = plusMinus;
    }

    public String getIndex() {
        return index;
    }

    public void setIndex(String index) {
        this.index = index;
    }

    public String getMaturityDate() {
        return maturityDate;
    }

    public void setMaturityDate(String maturityDate) {
        this.maturityDate = maturityDate;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

}
