package com.learning;

import com.thoughtworks.xstream.annotations.XStreamAlias;

/**
 *
 * @author Herman Sheppard
 *
 * XStream object wrapping for XML received from nBol.
 *
 */

@XStreamAlias("AcctId")
public class NBolXMLAccountId {

    @XStreamAlias("Id")
    private String id;

    @XStreamAlias("Iban")
    private String iban;

    public void setId(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public String getIban() {
        return iban;
    }

    public void setIban(String iban) {
        this.iban = iban;
    }
}

