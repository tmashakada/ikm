package com.learning;


import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("address")
public class ResidentialAddress extends BaseObject{
    @XStreamAlias("residential")
    private Residential residental;
    @XStreamAlias("postal")
    private Residential postal;

    public Residential getResidental() {
        return residental;
    }
    public void setResidental(Residential residental) {
        this.residental = residental;
    }
    public Residential getPostal() {
        return postal;
    }
    public void setPostal(Residential postal) {
        this.postal = postal;
    }


}
