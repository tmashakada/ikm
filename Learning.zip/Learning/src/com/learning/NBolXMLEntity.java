package com.learning;


import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("Entity")
public class NBolXMLEntity extends BaseObject{

    @XStreamAlias("EntityTypeName")
    private String entityTypeName;

    @XStreamAlias("EntityTypeDetails")
    private NBolXMLEntityTypeDetails entityTypeDetails;

    public String getEntityTypeName() {
        return entityTypeName;
    }

    public void setEntityTypeName(String entityTypeName) {
        this.entityTypeName = entityTypeName;
    }

    public NBolXMLEntityTypeDetails getEntityTypeDetails() {
        return entityTypeDetails;
    }

    public void setEntityTypeDetails(NBolXMLEntityTypeDetails entityTypeDetails) {
        this.entityTypeDetails = entityTypeDetails;
    }


}
