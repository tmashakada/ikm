package com.learning;


import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

/**
 *
 * @author Herman Sheppard
 *
 * XStream object wrapping for XML received from nBol.
 *
 */

@XStreamAlias("InstdAmt")
public class NBolXMLCurrencyAmount extends BaseObject{

    private static final long serialVersionUID = -3045472820367491200L;

    @XStreamAsAttribute
    private String Ccy;


    private String value;

    public void setCcy(String ccy) {
        Ccy = ccy;
    }

    public String getCcy() {
        return Ccy;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

}

