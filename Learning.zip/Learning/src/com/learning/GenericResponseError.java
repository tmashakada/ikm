package com.learning;

import com.thoughtworks.xstream.annotations.XStreamAlias;



import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("error")
public class GenericResponseError extends BaseObject {

    private static final long serialVersionUID = 2536532157602027688L;

    private String code;

    private String description;

    private String fieldReference;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getFieldReference() {
        return fieldReference;
    }

    public void setFieldReference(String fieldReference) {
        this.fieldReference = fieldReference;
    }

}
