package com.learning;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;
import com.thoughtworks.xstream.io.xml.StaxDriver;
import com.thoughtworks.xstream.security.ArrayTypePermission;
import java.util.Objects;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class TestReadXML {

    public  static  void  main(String [] arc) {
       // NBolXMLWrapperXStream  msg=readNBolXMLWrapperXStream ();
         test2();
       // test9();

   //   System.out.println(test4());
       // testFinal();
       // System.out.println("bbbbbbbbb"+ StringUtils.isNotBlank(test4()));
     // if(!test4().isEmpty()){
         //System.out.println("bbbbbbbbb");




    }

    public  static  void  test9(){
        String s = "543234asfg";
        System.out.printf("The output of StringUtils.isNotBlank() for the string - '%s' is %s", s, StringUtils.isNotBlank(s));
        System.out.println();

        s = "";
        System.out.printf("The output of StringUtils.isNotBlank() for the string - '%s' is %s", s, StringUtils.isNotBlank(s));
        System.out.println();

        s = null;
        System.out.printf("The output of StringUtils.isNotBlank() for the string - '%s' is %s", s, StringUtils.isNotBlank(s));
        System.out.println();

        s = "    \n\t";
        System.out.printf("The output of StringUtils.isNotBlank() for the string - '%s' is %s", s, StringUtils.isNotBlank(s));
        System.out.println();
    }
public static String  test4(){
    return CommonConstants.DefaultValues.EMPTY_STRING;
}

    public static String getDecodedJsonObject(NBolXMLInstruction nBolXMLInstruction){
        for (NBolXMLTransaction nBolXMLTransaction:nBolXMLInstruction.getnBolTransaction() ){
            System.out.println( "Trans Type" +nBolXMLTransaction.getTransactionType());
            Optional<BalanceOfPayment> balanceOfPayment=Optional.ofNullable(nBolXMLTransaction.getBalanceOfPayment());
            if(balanceOfPayment.isPresent()&&!balanceOfPayment.get().getLibraData().isEmpty()){
                Boolean isBase64=  Base64.isBase64(balanceOfPayment.get().getLibraData());
                if(Boolean.TRUE.equals(isBase64)){
                    System.out.println( "Dec" +new String(Base64.decodeBase64(balanceOfPayment.get().getLibraData())));
                    return  new String(Base64.decodeBase64(balanceOfPayment.get().getLibraData()));
                }else {
                    System.out.println( "Not " +balanceOfPayment.get().getLibraData());
                    return balanceOfPayment.get().getLibraData();
                }
            }
        }
        return CommonConstants.DefaultValues.EMPTY_STRING;
    }

    public static String getDecodedJsonObject2(NBolXMLInstruction nBolXMLInstruction){
        for (NBolXMLTransaction nBolXMLTransaction:nBolXMLInstruction.getnBolTransaction() ){
            System.out.println( "Trans Type" +nBolXMLTransaction.getTransactionType());
            Optional<BalanceOfPayment> balanceOfPayment=Optional.ofNullable(nBolXMLTransaction.getBalanceOfPayment());
            if(balanceOfPayment.isPresent()&&!balanceOfPayment.get().getLibraData().isEmpty()){
                Boolean isBase64=  Base64.isBase64(balanceOfPayment.get().getLibraData());
                if(Boolean.TRUE.equals(isBase64)){
                    return  new String(Base64.decodeBase64(balanceOfPayment.get().getLibraData()));
                }else {
                    return balanceOfPayment.get().getLibraData();
                }
            }
        }
        return CommonConstants.DefaultValues.EMPTY_STRING;
    }
    public  static  void testFinal(){
        XStream xstream = new XStream(new StaxDriver());
        xstream.processAnnotations(NBolXMLWrapperXStream.class);
        Class<?>[] classes=new Class[]{NBolXMLWrapperXStream.class};
        xstream.allowTypes(classes);

       // NBolXMLWrapperXStream nBolMessage=(NBolXMLWrapperXStream)xstream.fromXML(XmlStr.xmlEncodeMTRNS);
         NBolXMLWrapperXStream nBolMessage=(NBolXMLWrapperXStream)xstream.fromXML(XmlStr.xmlMTRNS);
        //NBolXMLWrapperXStream nBolMessage=(NBolXMLWrapperXStream)xstream.fromXML(XmlStr.xmlSTRNS);
        //NBolXMLWrapperXStream nBolMessage=(NBolXMLWrapperXStream)xstream.fromXML(XmlStr.xmlSTRNSEmpty);
        //NBolXMLWrapperXStream nBolMessage=(NBolXMLWrapperXStream)xstream.fromXML(XmlStr.xmlSTRNSEncoded);
        //  NBolXMLWrapperXStream nBolMessage=(NBolXMLWrapperXStream)xstream.fromXML(XmlStr.xmlSTRNSNotAva);
        //System.out.println(XmlStr.xmlEncodeMTRNS);
        System.out.println(nBolMessage.getBatchNumber());
        //

        final List<NBolXMLInstruction> nBolInstructionList = nBolMessage.getInstr();
        int count=0;
        for (NBolXMLInstruction nBolXMLInstruction : nBolInstructionList) {
            count++;
            System.out.println( "InstructionId "+ nBolXMLInstruction.getInstructionId());
            System.out.println(count);

            String bb= getDecodedJsonObject(nBolXMLInstruction);
          //  System.out.println(bb);
            }



    }
public  static  void test2(){
   // NBolXMLWrapperXStream  nBolXMLWrapperXStream=new

   // XStream xstream = new XStream();
    XStream xstream = new XStream(new StaxDriver());
    xstream.processAnnotations(NBolXMLWrapperXStream.class);
    Class<?>[] classes=new Class[]{NBolXMLWrapperXStream.class};
    xstream.allowTypes(classes);
    /**
    xstream.allowTypesByWildcard(new String[]{
            "java.util.**",
            "com.learning.**"
    });
     **/
    //NBolXMLWrapperXStream nBolMessage=(NBolXMLWrapperXStream)xstream.fromXML(XmlStr.xmlEncodeMTRNS);
    NBolXMLWrapperXStream nBolMessage=(NBolXMLWrapperXStream)xstream.fromXML(XmlStr.xmlMTRNS);
     //NBolXMLWrapperXStream nBolMessage=(NBolXMLWrapperXStream)xstream.fromXML(XmlStr.xmlSTRNS);
    // NBolXMLWrapperXStream nBolMessage=(NBolXMLWrapperXStream)xstream.fromXML(XmlStr.xmlSTRNSEmpty);
    // NBolXMLWrapperXStream nBolMessage=(NBolXMLWrapperXStream)xstream.fromXML(XmlStr.xmlSTRNSEncoded);
    //  NBolXMLWrapperXStream nBolMessage=(NBolXMLWrapperXStream)xstream.fromXML(XmlStr.xmlNoBalanceofPaymen);
   //  NBolXMLWrapperXStream nBolMessage=(NBolXMLWrapperXStream)xstream.fromXML(XmlStr.xmlSTRNSNotAva);
    //System.out.println(XmlStr.xmlEncodeMTRNS);
    System.out.println(nBolMessage.getBatchNumber());


    final List<NBolXMLInstruction> nBolInstructionList = nBolMessage.getInstr();


    int count=0;
    for (NBolXMLInstruction nBolXMLInstruction : nBolInstructionList) {
         count++;
          System.out.println( "InstructionId"+ nBolXMLInstruction.getInstructionId());
          System.out.println(count);
          int b=0;
       // getDecodedJsonObject(nBolXMLInstruction);
          for (NBolXMLTransaction nBolXMLTransaction:nBolXMLInstruction.getnBolTransaction() ){


            //  System.out.println( "JSONmmm OBject vv "+nBolXMLTransaction.getTransactionType() );System.out.println( "
              System.out.println( "=========================================");
              System.out.println( "Transaction Id :"+nBolXMLTransaction.getTransactionId());
             // String bb =  getDecodedLibraData( nBolXMLTransaction);
              String bb = getDecodedLibraData7( nBolXMLTransaction);
              System.out.println( " Librab  "+bb );
              System.out.println( "=========================================");



          }
    }





}
public static String getDecodedLibraData3(final NBolXMLTransaction nBolTrx) {

        if (!nBolTrx.getTransactionType()
                .equalsIgnoreCase(AccConstants.Accounting.CREDIT_TRANSACTION)) {
            return CommonConstants.DefaultValues.EMPTY_STRING;
        }

        final BalanceOfPayment bop = nBolTrx.getBalanceOfPayment();
        final Optional< String > libraData = Optional.ofNullable(bop.getLibraData());

        if (!libraData.isPresent()) {
            return CommonConstants.DefaultValues.EMPTY_STRING;
        }

        return Base64.isBase64(bop.getLibraData()) ?
                new String(Base64.decodeBase64(bop.getLibraData())) :
                bop.getLibraData();

    }
    public static String getDecodedLibraData4(final NBolXMLTransaction nBolTrx) {

        if (!nBolTrx.getTransactionType()
            .equalsIgnoreCase(AccConstants.Accounting.CREDIT_TRANSACTION)) {
            return CommonConstants.DefaultValues.EMPTY_STRING;
        }
        final Optional< BalanceOfPayment> bopOpt = Optional.ofNullable(nBolTrx.getBalanceOfPayment());
        if (!bopOpt.isPresent()) {
            return CommonConstants.DefaultValues.EMPTY_STRING;
        }

        final Optional< String > libraData = Optional.ofNullable(bopOpt.get().getLibraData());

        if (!libraData.isPresent()) {
            return CommonConstants.DefaultValues.EMPTY_STRING;
        }

        return Base64.isBase64(bopOpt.get().getLibraData()) ?
            new String(Base64.decodeBase64(bopOpt.get().getLibraData())) :
            bopOpt.get().getLibraData();

    }
    public static String getDecodedLibraData5(final NBolXMLTransaction nBolTrx) {

       // if (!AccConstants.Accounting.CREDIT_TRANSACTION.equalsIgnoreCase(nBolTrx.getTransactionType())){
        //    return CommonConstants.DefaultValues.EMPTY_STRING;
       // }
        if(!AccConstants.Accounting.CREDIT_TRANSACTION.equalsIgnoreCase(nBolTrx.getTransactionType()) || Objects.isNull(nBolTrx.getBalanceOfPayment())||StringUtils.isEmpty(nBolTrx.getBalanceOfPayment().getLibraData())){
           return CommonConstants.DefaultValues.EMPTY_STRING;
        }

        final String libraData=nBolTrx.getBalanceOfPayment().getLibraData();
        return Base64.isBase64(libraData) ? new String(Base64.decodeBase64(libraData)) :libraData;

    }
    public static String getDecodedLibraData7(final NBolXMLTransaction nBolTrx) {

        if( !AccConstants.Accounting.CREDIT_TRANSACTION.equalsIgnoreCase(nBolTrx.getTransactionType()) || Objects.isNull(nBolTrx.getBalanceOfPayment()) || StringUtils.isEmpty(nBolTrx.getBalanceOfPayment().getLibraData())){
            return CommonConstants.DefaultValues.EMPTY_STRING;
        }
        final String libraData=nBolTrx.getBalanceOfPayment().getLibraData();
        return Base64.isBase64(libraData) ? new String(Base64.decodeBase64(libraData)) :libraData;

    }

    public static String getDecodedLibraData6(final NBolXMLTransaction nBolTrx) {

        if (!AccConstants.Accounting.CREDIT_TRANSACTION.equalsIgnoreCase(nBolTrx.getTransactionType())){
            return CommonConstants.DefaultValues.EMPTY_STRING;
        }

        if (Objects.isNull(nBolTrx.getBalanceOfPayment()) || nBolTrx.getBalanceOfPayment().getLibraData().isEmpty()){
            return CommonConstants.DefaultValues.EMPTY_STRING;
        }
        final String libraData=nBolTrx.getBalanceOfPayment().getLibraData();
        return Base64.isBase64(libraData) ? new String(Base64.decodeBase64(libraData)) :libraData;

    }
    public static String getDecodedLibraData2(NBolXMLTransaction nBolXMLTransaction) {
    System.out.println( "vvv "+AccConstants.Accounting.CREDIT_TRANSACTION);
    //transactionType == AccConstants.NbolConstants.CREDIT_TRANSACTION
    if(nBolXMLTransaction.getTransactionType().equalsIgnoreCase(AccConstants.Accounting.CREDIT_TRANSACTION)){
        System.out.println( "JSONmmm OBject  " +" "+nBolXMLTransaction.getTransactionType());
        BalanceOfPayment balanceOfPayment=nBolXMLTransaction.getBalanceOfPayment();
        Optional<String> libraData= Optional.ofNullable(balanceOfPayment.getLibraData());
        if(libraData.isPresent()){
            Boolean isBase64=  Base64.isBase64(balanceOfPayment.getLibraData());
            if(isBase64) {
                String decodedString = new String(Base64.decodeBase64(balanceOfPayment.getLibraData()));
               // System.out.println( "JSON OBject  "+ decodedString );
                return decodedString;
            }else {
                System.out.println( "JSON OBject Not Encode "+balanceOfPayment.getLibraData());
                return balanceOfPayment.getLibraData();
            }
        }else{
            System.out.println( "JSON OBject empty  " );
            return CommonConstants.DefaultValues.EMPTY_STRING;
        }
    }
    return CommonConstants.DefaultValues.EMPTY_STRING;
}
public static String getDecodedLibraData(NBolXMLTransaction nBolXMLTransaction) {

    if(nBolXMLTransaction.getTransactionType().equalsIgnoreCase(AccConstants.Accounting.CREDIT_TRANSACTION)){
        BalanceOfPayment balanceOfPayment=nBolXMLTransaction.getBalanceOfPayment();
        Optional<String> libraData= Optional.ofNullable(balanceOfPayment.getLibraData());
        if(libraData.isPresent()){
            Boolean isBase64 = Base64.isBase64(balanceOfPayment.getLibraData());
            if (Boolean.TRUE.equals(isBase64)) {
                return new String(Base64.decodeBase64(balanceOfPayment.getLibraData()));
            }else{
                return balanceOfPayment.getLibraData();
            }
        }else{
            return CommonConstants.DefaultValues.EMPTY_STRING;
        }
    }
    return CommonConstants.DefaultValues.EMPTY_STRING;

    }

    public  static  void Test3(){
        // NBolXMLWrapperXStream  nBolXMLWrapperXStream=new

        // XStream xstream = new XStream();
        XStream xstream = new XStream(new StaxDriver());
        xstream.processAnnotations(NBolXMLWrapperXStream.class);
        Class<?>[] classes=new Class[]{NBolXMLWrapperXStream.class};
        xstream.allowTypes(classes);
        /**
         xstream.allowTypesByWildcard(new String[]{
         "java.util.**",
         "com.learning.**"
         });
         **/
        NBolXMLWrapperXStream nBolMessage=(NBolXMLWrapperXStream)xstream.fromXML(XmlStr.xmlEncodeMTRNS);
        // NBolXMLWrapperXStream nBolMessage=(NBolXMLWrapperXStream)xstream.fromXML(XmlStr.xmlMTRNS);
        //NBolXMLWrapperXStream nBolMessage=(NBolXMLWrapperXStream)xstream.fromXML(XmlStr.xmlSTRNS);
        //NBolXMLWrapperXStream nBolMessage=(NBolXMLWrapperXStream)xstream.fromXML(XmlStr.xmlSTRNSEmpty);
        //NBolXMLWrapperXStream nBolMessage=(NBolXMLWrapperXStream)xstream.fromXML(XmlStr.xmlSTRNSEncoded);
        //  NBolXMLWrapperXStream nBolMessage=(NBolXMLWrapperXStream)xstream.fromXML(XmlStr.xmlSTRNSNotAva);
        //System.out.println(XmlStr.xmlEncodeMTRNS);
        System.out.println(nBolMessage.getBatchNumber());


        final List<NBolXMLInstruction> nBolInstructionList = nBolMessage.getInstr();
        int count=0;
        for (NBolXMLInstruction nBolXMLInstruction : nBolInstructionList) {
            count++;
            System.out.println( "InstructionId"+ nBolXMLInstruction.getInstructionId());
            System.out.println(count);
            int b=0;
            //List<NBolXMLTransaction> transactionList = nBolXMLInstruction.getnBolTransaction();
            for (NBolXMLTransaction nBolXMLTransaction:nBolXMLInstruction.getnBolTransaction() ){
                b++;
                BalanceOfPayment bb= nBolXMLTransaction.getBalanceOfPayment();
                //  System.out.println( String.format("Balance  of Payments '%s'  '%s'",b,bb));
                Optional<BalanceOfPayment> balanceOfPayment=Optional.ofNullable(nBolXMLTransaction.getBalanceOfPayment());

                if(balanceOfPayment.isPresent()){

                    System.out.println( "TransId  "+ nBolXMLTransaction.getTransactionId());
                    System.out.println( "Balance of Payment NOT NULL");
                    System.out.println( "LibraData  "+ balanceOfPayment.get().getLibraData());
                    //docRequest.setRegisteringBranch(StringUtils.isNotBlank(frontOfficeCode)
                    if(!balanceOfPayment.get().getLibraData().isEmpty()){

                        Boolean isBase64=  Base64.isBase64(balanceOfPayment.get().getLibraData());
                        if(isBase64){
                            Base64 base64 = new Base64();
                            //  String decodedString = new String(base64.decode(balanceOfPayment.get().getLibraData()));
                            String decodedString = new String(Base64.decodeBase64(balanceOfPayment.get().getLibraData()));

                            //  final String decodedString = Base64.decodeBase64(balanceOfPayment.get().getLibraData());
                            balanceOfPayment.get().setLibraData(decodedString);
                        }
                        System.out.println( "JSON OBject  "+ balanceOfPayment.get().getLibraData());

                    }else{
                        System.out.println( "LibraData IsEmpty ");
                        System.out.println( "Create OT Request orINTR Request withou JSON OBJECT ");
                    }



                }else {

                    System.out.println( "TransId  "+ nBolXMLTransaction.getTransactionId());
                    System.out.println( "LibraData Tag Not Found  ");
                    System.out.println( "Create OT Request or INTR Request without JSON OBJECT");

                }

                //System.out.println(bb.getBopSequenceNumber());

            }
        }





    }

    public static void test() {
        String bb="C:\\workspace\\ban.xml";
        //FileReader reader = new FileReader( bb);  // load file
        File xmlFile = new File(bb+ ".xml");
        XStream xstream = new XStream();
        xstream.processAnnotations(Data.class);     // inform XStream to parse annotations in Data class
       // xstream.processAnnotations(Ban.class);      // and in two other classes...
       // xstream.processAnnotations(Person.class);   // we use for mappings
        try{
        Data data = (Data) xstream.fromXML(xmlFile); // parse

        // Print some data to console to see if results are correct
        System.out.println("Number of bans = " + data.getBans().size());

        //Ban firstBan = data.getBans().get(0);
     //   System.out.println("First ban = " + firstBan.toString());
        }catch(Exception e){
            System.err.println("Error in XML Read: " + e.getMessage());
        }
    }
    public static  NBolXMLWrapperXStream  readNBolXMLWrapperXStream () {
        System.out.println("read NBolXMLWrapperXStream ");

        String file_path="C:\\workspace\\Learning\\src\\com\\learning\\SZ NBOL REQUEST WITH ENCODED JSON OBJECT - MULTI TRNS";
        XStream xstream = new XStream(new DomDriver());
        NBolXMLWrapperXStream nbol= new NBolXMLWrapperXStream(); //if there is an error during deserialization, this is going to be returned, is this what you want?
        try{
            File xmlFile = new File(file_path+ ".xml");
            nbol = (NBolXMLWrapperXStream) xstream.fromXML(xmlFile);
        }catch(Exception e){
            System.err.println("Error in XML Read: " + e.getMessage());
        }
        return nbol;
    }
}
