package com.learning;

import com.thoughtworks.xstream.annotations.XStreamAlias;

public class EEPaymentInstructionMessage {
  private String countryISO;
  private String buCode;
  private String productCode;
  @XStreamAlias("DB_CCY")
  private String debitCurrencyCode;
  @XStreamAlias("CR_CCY")
  private String creditCurrencyCode;
  @XStreamAlias("X103_ACC_BKSW_57A")
  private String accountBksw;

  public EEPaymentInstructionMessage() {
  }

  public String getCountryISO() {
    return countryISO;
  }

  public void setCountryISO(String countryISO) {
    this.countryISO = countryISO;
  }

  public String getBuCode() {
    return buCode;
  }

  public void setBuCode(String buCode) {
    this.buCode = buCode;
  }

  public String getProductCode() {
    return productCode;
  }

  public void setProductCode(String productCode) {
    this.productCode = productCode;
  }

  public String getDebitCurrencyCode() {
    return debitCurrencyCode;
  }

  public void setDebitCurrencyCode(String debitCurrencyCode) {
    this.debitCurrencyCode = debitCurrencyCode;
  }

  public String getCreditCurrencyCode() {
    return creditCurrencyCode;
  }

  public void setCreditCurrencyCode(String creditCurrencyCode) {
    this.creditCurrencyCode = creditCurrencyCode;
  }

  public String getAccountBksw() {
    return accountBksw;
  }

  public void setAccountBksw(String accountBksw) {
    this.accountBksw = accountBksw;
  }
}
