package com.learning;


import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("IndividualType")
public class NBolXMLIndividualType extends BaseObject{

    @XStreamAlias("Surname")
    private String surname;

    @XStreamAlias("Gender")
    private String gender;

    @XStreamAlias("PassportNumber")
    private String passportNumber;

    @XStreamAlias("PassportCountry")
    private String passportCountry;

    @XStreamAlias("DateOfBirth")
    private String dateOfBirth;

    @XStreamAlias("IDNumber")
    private String idNumber;

    @XStreamAlias("TempResPermitNumber")
    private String tempResPermitNumber;

    @XStreamAlias("ForeignIDNumber")
    private String foreignIdNumber;

    @XStreamAlias("ForeignCountry")
    private String foreignCountry;

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getPassportNumber() {
        return passportNumber;
    }

    public void setPassportNumber(String passportNumber) {
        this.passportNumber = passportNumber;
    }

    public String getPassportCountry() {
        return passportCountry;
    }

    public void setPassportCountry(String passportCountry) {
        this.passportCountry = passportCountry;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getIdNumber() {
        return idNumber;
    }

    public void setIdNumber(String idNumber) {
        this.idNumber = idNumber;
    }

    public String getTempResPermitNumber() {
        return tempResPermitNumber;
    }

    public void setTempResPermitNumber(String tempResPermitNumber) {
        this.tempResPermitNumber = tempResPermitNumber;
    }

    public String getForeignIdNumber() {
        return foreignIdNumber;
    }

    public void setForeignIdNumber(String foreignIdNumber) {
        this.foreignIdNumber = foreignIdNumber;
    }

    public String getForeignCountry() {
        return foreignCountry;
    }

    public void setForeignCountry(String foreignCountry) {
        this.foreignCountry = foreignCountry;
    }



}
