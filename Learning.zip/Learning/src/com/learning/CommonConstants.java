package com.learning;

public class CommonConstants {
    public interface DefaultValues {
        public static final String EMPTY_STRING = "";
    }
}
