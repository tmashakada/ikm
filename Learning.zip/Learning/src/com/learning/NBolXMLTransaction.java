package com.learning;

import com.thoughtworks.xstream.annotations.XStreamImplicit;

import java.util.List;



import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamConverter;
import com.thoughtworks.xstream.annotations.XStreamImplicit;
import org.apache.commons.lang3.StringUtils;

/**
 *
 * @author Herman Sheppard
 *
 * XStream object wrapping for XML received from nBol.
 *
 */

public class NBolXMLTransaction extends BaseObject{

    private static final long serialVersionUID = -3045472720367491200L;

    @XStreamAlias("TrnsId")
    private String transactionId;

    @XStreamAlias("Desc")
    private String description;

    @XStreamAlias("TrnTp")
    private String transactionType;

    @XStreamConverter(value = NBolXMLCurrencyAmountConverter.class)
    @XStreamAlias("InstdAmt")
    private NBolXMLCurrencyAmount instdAmount;

    @XStreamAlias("EqvtAmt")
    private NBolXMLEquivalentAmount equivalentAmount;

    @XStreamAlias("RateSource")
    private String rateSource;

    @XStreamAlias("CorrespondingAgt")
    private NBolXMLCorrespondingAgt correspondingAgt;

    @XStreamAlias("AcctOwner")
    private NBolXMLAccountOwner accountOwner;

    @XStreamAlias("Acct")
    private NBolXMLAccount account;

    @XStreamAlias("Agt")
    private NBolXMLAgt agt;

    @XStreamAlias("IntermediaryAgt")
    private NBolXMLAgt intermediaryAgt;

    @XStreamAlias("ChrgBr")
    private String chargeBr;

    @XStreamAlias("XchgCtrctRef")
    private String exchangeRateCtrctReference;

    @XStreamAlias("XchgRt")
    private String exchangeRate;

    @XStreamAlias("XchgRtQtnMthd")
    private String exchangeRateQtnMethod;

    @XStreamAlias("XchgRtQtnDt")
    private String exchangeRateQtnDate;

    @XStreamAlias("PmtReason")
    private String pmtReason;

    @XStreamAlias("WorkFlowReferenceNumber")
    private String workflowReference;

    @XStreamAlias("BalanceOfPayment")
    private BalanceOfPayment balanceOfPayment;

    @XStreamImplicit(itemFieldName = "TransactionProcessingOption")
    private List<TransactionProcessingOption> transactionProcessingOption;

    @XStreamImplicit
    @XStreamAlias("bopDetails")
    private List<BopDetails> bopDetails;

    @XStreamImplicit(itemFieldName = "Document")
    private List<NBolXMLDocument> documents;

    @XStreamAlias("CoverNumber")
    private String coverNumber;

    @XStreamAlias("SecChrgCode")
    private String securityChargeCode;

    @XStreamAlias("Flow")
    private String bopFlow;

    @XStreamAlias("NomChrgAccNm")
    private String chargeAccount;

    @XStreamAlias("ReportingQualifier")
    private String reportingQualifier;

    private String transactionReference;
    private String statementReference;
    private String remitterCountry;
    private String complianceType;

    //start nbol ITT excon data	on trn level
    private String exconDate;
    private String exconNumber;
    private String sarbAuthAppNumber;
    private String exconDealer;
    //end nbol ITT excon data

    private String nominatedChargeAccountCurrency;

    @XStreamAlias("ExFreeTxtFxInfo")
    private String exFreeTextFXInfo;

    @XStreamAlias("BankToBank")
    private String bankToBank;

    @XStreamAlias("DueDiligenceRefNumber")
    private String dueDiligenceRefNumber;

    @XStreamAlias("ItemizedOrderingAcntRef")
    private String itemizedOrderingAcntRef;

    private Bop bop;

    public boolean hasBOPField() {
        return getBalanceOfPayment() == null ? false : StringUtils.isNotBlank(getBalanceOfPayment().getCode());
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public void setInstdAmount(NBolXMLCurrencyAmount instdAmount) {
        this.instdAmount = instdAmount;
    }

    public NBolXMLCurrencyAmount getInstdAmount() {
        return instdAmount;
    }

    public void setEquivalentAmount(NBolXMLEquivalentAmount equivalentAmount) {
        this.equivalentAmount = equivalentAmount;
    }

    public NBolXMLEquivalentAmount getEquivalentAmount() {
        return equivalentAmount;
    }

    public void setRateSource(String rateSource) {
        this.rateSource = rateSource;
    }

    public String getRateSource() {
        return rateSource;
    }

    public void setAccountOwner(NBolXMLAccountOwner accountOwner) {
        this.accountOwner = accountOwner;
    }

    public NBolXMLAccountOwner getAccountOwner() {
        return accountOwner;
    }

    public void setChargeBr(String chargeBr) {
        this.chargeBr = chargeBr;
    }

    public String getChargeBr() {
        return chargeBr;
    }

    public void setAccount(NBolXMLAccount account) {
        this.account = account;
    }

    public NBolXMLAccount getAccount() {
        return account;
    }

    public void setAgt(NBolXMLAgt agt) {
        this.agt = agt;
    }

    public NBolXMLAgt getAgt() {
        return agt;
    }

    public void setExchangeRate(String exchangeRate) {
        this.exchangeRate = exchangeRate;
    }

    public String getExchangeRate() {
        return exchangeRate;
    }

    public void setExchangeRateQtnMethod(String exchangeRateQtnMethod) {
        this.exchangeRateQtnMethod = exchangeRateQtnMethod;
    }

    public String getExchangeRateQtnMethod() {
        return exchangeRateQtnMethod;
    }

    public void setPmtReason(String pmtReason) {
        this.pmtReason = pmtReason;
    }

    public String getPmtReason() {
        return pmtReason;
    }

    public void setExchangeRateCtrctReference(String exchangeRateCtrctReference) {
        this.exchangeRateCtrctReference = exchangeRateCtrctReference;
    }

    public String getExchangeRateCtrctReference() {
        return exchangeRateCtrctReference;
    }

    public void setExchangeRateQtnDate(String exchangeRateQtnDate) {
        this.exchangeRateQtnDate = exchangeRateQtnDate;
    }

    public String getExchangeRateQtnDate() {
        return exchangeRateQtnDate;
    }

    public BalanceOfPayment getBalanceOfPayment() {
        return balanceOfPayment;
    }

    public void setBalanceOfPayment(BalanceOfPayment balanceOfPayment) {
        this.balanceOfPayment = balanceOfPayment;
    }

    public NBolXMLCorrespondingAgt getCorrespondingAgt() {
        return correspondingAgt;
    }

    public void setCorrespondingAgt(NBolXMLCorrespondingAgt correspondingAgt) {
        this.correspondingAgt = correspondingAgt;
    }

    public List<TransactionProcessingOption> getTransactionProcessingOption() {
        return transactionProcessingOption;
    }

    public void setTransactionProcessingOption(List<TransactionProcessingOption> transactionProcessingOption) {
        this.transactionProcessingOption = transactionProcessingOption;
    }

    public String getCoverNumber() {
        return coverNumber;
    }

    public void setCoverNumber(String coverNumber) {
        this.coverNumber = coverNumber;
    }

    public List<BopDetails> getBopDetails() {
        return bopDetails;
    }

    public void setBopDetails(List<BopDetails> bopDetails) {
        this.bopDetails = bopDetails;
    }

    public List<NBolXMLDocument> getDocuments() {
        return documents;
    }

    public void setDocuments(List<NBolXMLDocument> documents) {
        this.documents = documents;
    }

    public String getWorkflowReference() {
        return workflowReference;
    }

    public void setWorkflowReference(String workflowReference) {
        this.workflowReference = workflowReference;
    }

    public NBolXMLAgt getIntermediaryAgt() {
        return intermediaryAgt;
    }

    public void setIntermediaryAgt(NBolXMLAgt intermediaryAgt) {
        this.intermediaryAgt = intermediaryAgt;
    }

    public String getSecurityChargeCode() {
        return securityChargeCode;
    }

    public void setSecurityChargeCode(String securityChargeCode) {
        this.securityChargeCode = securityChargeCode;
    }

    public String getBopFlow() {
        return bopFlow;
    }

    public void setBopFlow(String bopFlow) {
        this.bopFlow = bopFlow;
    }

    public String getChargeAccount() {
        return chargeAccount;
    }

    public void setChargeAccount(String chargeAccount) {
        this.chargeAccount = chargeAccount;
    }

    public String getReportingQualifier() {
        return reportingQualifier;
    }

    public void setReportingQualifier(String reportingQualifier) {
        this.reportingQualifier = reportingQualifier;
    }

    public String getTransactionReference() {
        return transactionReference;
    }

    public void setTransactionReference(String transactionReference) {
        this.transactionReference = transactionReference;
    }

    public String getStatementReference() {
        return statementReference;
    }

    public void setStatementReference(String statementReference) {
        this.statementReference = statementReference;
    }

    public String getRemitterCountry() {
        return remitterCountry;
    }

    public void setRemitterCountry(String remitterCountry) {
        this.remitterCountry = remitterCountry;
    }

    public String getComplianceType() {
        return complianceType;
    }

    public void setComplianceType(String complianceType) {
        this.complianceType = complianceType;
    }

    public String getExconDate() {
        return exconDate;
    }

    public void setExconDate(String exconDate) {
        this.exconDate = exconDate;
    }

    public String getExconNumber() {
        return exconNumber;
    }

    public void setExconNumber(String exconNumber) {
        this.exconNumber = exconNumber;
    }

    public String getSarbAuthAppNumber() {
        return sarbAuthAppNumber;
    }

    public void setSarbAuthAppNumber(String sarbAuthAppNumber) {
        this.sarbAuthAppNumber = sarbAuthAppNumber;
    }

    public String getExconDealer() {
        return exconDealer;
    }

    public void setExconDealer(String exconDealer) {
        this.exconDealer = exconDealer;
    }

    public String getNominatedChargeAccountCurrency() {
        return nominatedChargeAccountCurrency;
    }

    public void setNominatedChargeAccountCurrency(String nominatedChargeAccountCurrency) {
        this.nominatedChargeAccountCurrency = nominatedChargeAccountCurrency;
    }

    public String getExFreeTextFXInfo() {
        return exFreeTextFXInfo;
    }

    public void setExFreeTextFXInfo(String exFreeTextFXInfo) {
        this.exFreeTextFXInfo = exFreeTextFXInfo;
    }

    public String getBankToBank() {
        return bankToBank;
    }

    public void setBankToBank(String bankToBank) {
        this.bankToBank = bankToBank;
    }

    public String getDueDiligenceRefNumber() {
        return dueDiligenceRefNumber;
    }

    public void setDueDiligenceRefNumber(String dueDiligenceRefNumber) {
        this.dueDiligenceRefNumber = dueDiligenceRefNumber;
    }

    public Bop getBop() {
        return bop;
    }

    public void setBop(Bop bop) {
        this.bop = bop;
    }

    public String getItemizedOrderingAcntRef() {
        return itemizedOrderingAcntRef;
    }

    public void setItemizedOrderingAcntRef(String itemizedOrderingAcntRef) {
        this.itemizedOrderingAcntRef = itemizedOrderingAcntRef;
    }

}
