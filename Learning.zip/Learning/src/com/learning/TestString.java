package com.learning;

public class TestString {

  public  static  void  main(String [] arc) {
    EEPaymentInstructionMessage request=new EEPaymentInstructionMessage();
    request.setAccountBksw("BW");
    request.setBuCode("BW02");
    request.setProductCode("INTR");
    request.setCreditCurrencyCode("USD");
    request.setDebitCurrencyCode("USD");
    request.setCountryISO("BW");
   final String RTGS = "RTGS";
   String nn= StpCutOffService.getProductCode(request.getProductCode());
    System.out.println("Test   "+nn);
    System.out.println("Test2   "+request.getAccountBksw());
    String beneficiaryCountryCode = SwiftUtils.getCountryFromBic(request.getAccountBksw());
    System.out.println("Test   "+beneficiaryCountryCode);

   boolean isRTGS= StpCutOffService.transactionTypeRTGS(request.getCountryISO(),request.getCreditCurrencyCode(),beneficiaryCountryCode);
    System.out.println("Test boolean   "+isRTGS);
  //  final boolean isRTGS = transactionTypeRTGS( request.getCountryISO(),  request.getCreditCurrencyCode(), beneficiaryCountryCode);
    final String pCode = nn + "_" + (isRTGS ? RTGS : request.getCreditCurrencyCode());
    System.out.println("Test pcode   "+pCode);

   String  itemName= StpCutOffService.getItemName("BW02",pCode);
    System.out.println("Test Item Name   "+itemName);
   //itemName = getItemName(sUnit.getCUnitCode(), productCode);
    String  itemName2= StpCutOffService.getItemName("BW02",nn);
    System.out.println("Test Item Name2   "+itemName2);
  }
 // AT


}
