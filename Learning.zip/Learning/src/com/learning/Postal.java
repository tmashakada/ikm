package com.learning;


import com.thoughtworks.xstream.annotations.XStreamAlias;

public class Postal extends BaseObject implements AddressType {

    @XStreamAlias("postalLine1")
    public String line1;

    @XStreamAlias("postalLine2")
    public String line2;

    @XStreamAlias("postalLine3")
    public String line3;

    @XStreamAlias("postalLine4")
    public String line4;

    @XStreamAlias("postalSuburb")
    public String suburb;

    @XStreamAlias("postalCity")
    public String city;

    @XStreamAlias("postalCode")
    public String code;

    @XStreamAlias("postalProvince")
    public String province;

    public String getLine1() {
        return line1;
    }

    public void setLine1(String line1) {
        this.line1 = line1;
    }

    public String getLine2() {
        return line2;
    }

    public void setLine2(String line2) {
        this.line2 = line2;
    }

    public String getLine3() {
        return line3;
    }

    public void setLine3(String line3) {
        this.line3 = line3;
    }

    public String getLine4() {
        return line4;
    }

    public void setLine4(String line4) {
        this.line4 = line4;
    }

    public String getSuburb() {
        return suburb;
    }

    public void setSuburb(String suburb) {
        this.suburb = suburb;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

}
