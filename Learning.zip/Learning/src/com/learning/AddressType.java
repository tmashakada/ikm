package com.learning;

public interface AddressType {
    public String getLine1();

    public String getLine2();

    public String getCity();

    public String getSuburb();

    public String getProvince();

    public String getCode();
}