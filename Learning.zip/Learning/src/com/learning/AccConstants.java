package com.learning;

public class AccConstants {

    public static final String BK_GROUP_ID = "STBANK";
    public static final String PCHG = "PCHG";
    public static final String CCHG = "CCHG";
    public static final String LCHG = "LCHG";
    public static final String PRINCIPAL_ID = "P";
    public static final String CHARGES_ID = "C";
    public static final String FUNDING_ID = "F";
    public static final String BLOCKING_ID = "B";
    public static final String CREDIT = "C";
    public static final String DEBIT = "D";
    public static final String PURCHASE = "P";
    public static final String SALE = "S";
    public static final String PROD_CODE = "N1";
    public static final String NO_INDICATOR = "N";
    public static final String YES_INDICATOR = "Y";
    public static final String PRINCIPAL_TYPE = "principal";
    public static final String CHARGES_TYPE = "charges";
    public static final String LIABILITY_ID = "L";
    public static final String REVERSAL = "R";

    /**
     * This is the id of the message saved in the database. After retrieving a
     * message the header will contain a property with this name.
     */

    public interface ReleaseTrn {
        public static final int INTEREST_RATE_TEST_NUMBER = 123456789;
        public static final String BALANCED_POST_TYPE = "balanced";
        public static final String SINGLE_SIDED_POST_TYPE = "singleSided";
    }

    public interface BlockUnblockFunds {
        public static final String block = "block";
        public static final String unblock = "unblock";
        public static final String BLOCK_REQUEST = "BLOCK:REQUEST";
        public static final String UNBLOCK_REQUEST = "UNBLOCK:REQUEST";
        public static final String DEFAULT_ERROR = "Default error for block/unblock, payload is :";
    }

    // CIB:PROCESS
    public interface Cib {
        public static final String FEDS_ENTRY_REQUEST = "FEDS_ENTRY:REQUEST";
        public static final String CFC_ENTRY_REQUEST = "CFC_ENTRY:REQUEST";
        public static final String FEDS_TRANBATCH_REQUEST = "FEDS_TRANBATCH:REQUEST";
        public static final String FEDS_FEED_OUT_REQUEST = "FEDS_FEED_OUT:REQUEST";
        public static final String FEDS_REV_REP_REQUEST = "FEDS_REV_REP:REQUEST";
        public static final String BOP_CD_PROCESS = "BOP:PROCESS";
    }

    // PBB:PROCESS
    public interface MoneyTransfer {
        public static final String PBB_ENTRY_REQUEST = "PBB_ENTRY:REQUEST";
    }

    public interface DataMining {
        public static final String PAY_REPORT = "PAY:REPORT";
        public static final String CBR_REPORT = "CBR:REPORT";
        public static final String COMMISSION_REPORT = "COMMISSION:REPORT";
        public static final String TRANSACTION_REPORT = "TRANSACTION:REPORT";
        public static final String EXPOSURE_REPORT = "EXPOSURE:REPORT";
        public static final String LOAN_REPORT = "LOAN:REPORT";
        public static final String INVOICE_REPORT = "INVOICE:REPORT";
        public static final String SBR_REPORT = "SBR:REPORT";
        public static final String TRANSACTION_REPORT_WS_REQUEST = "TRANSACTION_REPORT_WS:REQUEST";
        public static final String TRANSACTION_REPORT_WS_RESPONSE = "TRANSACTION_REPORT_WS:RESPONSE";
        public static final String TRAN_STATUS_R = "R";
        public static final String TRAN_STATUS_M = "M";
        public static final String COMMISSION = "COMMISSION";
        public static final String FRONT_OFFICE = "Front Office";

        public interface CbrReportStrategy {
            public static final String CURRENCY_PRINCIPLE = "PRINCIPLE";
            public static final String CURRENCY_SECONDARY = "SECONDARY";
            public static final String ORDERING_COUTNRY = "ORDERING_COUTNRY";
            public static final String RECIEVING_COUTNRY = "RECIEVING_COUTNRY";
            public static final String CORRESPONDING_COUTNRY = "CORRESPONDING_COUTNRY";
            public static final String TRANSACTION_REFERENCE = "TRANSACTION_REFERENCE";
            public static final String REFERENCE = "REFERENCE";
            public static final int RESIDENTIAL_ADDRESS = 1;
            public static final int POSTAL_ADDRESS = 2;
            public static final String BOOKING_RATE = "Booking Rate";
        }

        public interface PayReportStrategy {
            public static final String FIELD51 = "FIELD51";
            public static final String FIELD52 = "FIELD52";
            public static final String FIELD56 = "FIELD56";
            public static final String FIELD57 = "FIELD57";
            public static final String RELEASE = "RELEASE";
            public static final String CONFIRM = "CONFIRM";
            public static final String PARTIAL_RELEASE = "PARTIAL REL";
        }
    }

    public interface CIFCustomerAccountInfo {
        public static final String DEFAULT_ERROR = "Default error for customer info response, payload is :";
    }

    public interface BopProcess {
        public static final String AP_REQUEST = "AP_CREATE_EE:REQUEST";
        public static final String IVS_REQUEST = "IVS:REQUEST";
        public static final String BOP_REQUEST = "BOP:REQUEST";
        public static final String ARM_UPDATE = "ARM:UPDATE";
        public static final String ARM_CREATE_REQUEST = "ARM_CREATE:REQUEST";
    }

    public interface LibraProcess {
        String LIBRA_WS_REQUEST = "LIBRA:WS:REQUEST";
    }

    public interface AccountTypes {
        String CFC = "CFC";
    }

    public interface Accounting {

        public static final String CUSTOMER = "CUSTOMER";
        public static final String BANK = "BANK";
        public static final String INHOUSE = "INHOUSE";
        public static final String NOSTRO = "NOSTRO";
        public static final String VOSTRO = "VOSTRO";
        public static final String SIRESS = "SIRESS";

        public interface EntryType {
            String IDRX = "IDRX";
            String IDRR = "IDRR";
            String CFC = "CFC";
        }

        public static final String CUSTOMER_INDICATOR = "CI";
        public static final String BANK_INDICATOR = "BI";
        public static final String COMMISSION = "COMMISSION";
        public static final String RECORD_TYPE_SUNDRY_CREDIT = "SC";
        public static final String RECORD_TYPE_SUNDRY_DEBIT = "SD";
        public static final String RECORD_TYPE_LETTER_OF_CREDIT = "LC";

        // account details
        public static final String MULTIPLY_DIVIDE_IND_M = "M";
        public static final String MULTIPLY_DIVIDE_IND_D = "D";
        public static final String COMPLETE_TRN_REQUEST = "CompleteTrn";
        public static final String ENTRY_REQUEST = "ENTRY:REQUEST";
        public static final String CHARGES_REQUEST = "CHARGE:REQUEST";
        public static final String DEBIT_TRANSACTION = "D";
        public static final String CREDIT_TRANSACTION = "C";

        //charges
        public static final String CHARGES_OUR = "OUR";
        public static final String CHARGES_BEN = "BEN";
        public static final String CHARGES_SHA = "SHA";
        public static final String CHARGES_SBP = "SBP";

        //settlement routes
        public static final String SIRESS_WORD = "SIRESS";
        public static final String NOSVOS_WORD = "NOSVOS";
    }

    public interface CustomerAccountInfo {

        public static final String DEFAULT_C_TRX_STATUS = "M";
        public static final String DEFAULT_C_ADD_FLAG = "T";
    }

    public interface AccountUpdate {
        public static final int ZA_ACCOUNT_NUMBER_LENGTH = 16;
        public static final String ACCOUNT_NUMBER_OPEN = "OPEN";
        public static final String ACCOUNT_STYLE_ODA = "ODA";
        public static final String NON_CUSTOMER_STYLE = "CPTC";
    }

    public interface NbolConstants {
        public static final String CUSTOMER_OTT_INSTRUCTION_TEMPLATE = "PYMT_INSTR_REP";
        public static final String CUSTOMER_ITT_INSTRUCTION_TEMPLATE = "PYMT_INSTR_REQ";
        public static final String CHANNEL_NBOL_MULTI = "nBol Multi";
        public static final String PRIORITY_URGENT = "Urgent";
        public final int MIN_NBOLXMLTRANSACTION_COUNT = 2;
        public final int CREDIT_TRANSACTION = 1;
        public final int DEBIT_TRANSACTION = 2;
        public final int DEBIT_CREDIT_TRANSACTION = 3;
        public final int COUNTRY_CODE_SUBSTRING_START = 4;
        public final int COUNTRY_CODE_SUBSTRING_END = 6;
        public static final String NBOL_DOCSIGHTING_REQUEST = "NBOL_DOCSIGHTING:REQUEST";
        public static final String NBOL_DOCSIGHTING_RESPONSE = "NBOL_DOCSIGHTING:RESPONSE";
        public static final String NBOL_REQUEST = "NBOL:REQUEST";
        public static final String NBOL_RESPONSE = "NBOL:RESPONSE";
        public static final String docSightingRequest = "DocSightingRequest";
        public static final String DocSightingCancelRequest = "DocSightingCancelRequest";
        public static final String NBOL_DOCSIGHTING_STOP_REQUEST = "NBOL_DOCSIGHTING_STOP:REQUEST";
        public static final String NBOL_DOCSIGHTING_STOP_RESPONSE = "NBOL_DOCSIGHTING_STOP:RESPONSE";
        public static final String DocSightingRequestAckNack = "DocSightingRequestAckNack";
        public static final String DocSightingCancellationFeedback = "DocSightingCancellationFeedback";
        public static final String STP_CUTOFF_PROCESS = "STP_CUTOFF:PROCESS";
        public static final String NBOL_ACC_SUB_REQUEST = "NBOL_ACC_SUB:REQUEST";
        public static final String EE_TO_NBOL_INSTRUCTION_REQUEST = "EE_TO_NBOL_INSTRUCTION:REQUEST";
        public static final String FAIL_STATUS = "UFAIL";
        public static final String UANCF = "UANCF";
        public static final String PROCESS_STATUS = "Submitted for Processing";
        public static final String TRN_DESC = "The intechange above was processed by EE";
        public static final String NBOL_SUCCESS_RESPONSE = "NBOL:SUCCESS_RESPONSE";
        public static final String NBOL_RELEASE_REQUEST = "NBOL_RELEASE:REQUEST";
        public static final String NBOL_SWIFT_REQUEST = "NBOL_SWIFT:REQUEST";
        public static final String NBOL_FAILURE_REQUEST = "NBOL_FAILURE:REQUEST";

        public interface ProcessingOptionValues {
            public static final String ITEMIZED = "Itemized";
            public static final String CONSOLIDATED = "Consolidated";
            public static final String FORCE_POST = "ForcePost";
        }

        public interface ProcessingOptionNames {
            public static final String STATEMENT_POSTING_OPTION = "StatementPostingOption";
            public static final String PRIORITY = "Priority";
        }

    }

    public interface ExposureConstants {
        public static final int COUNTRY = 0;
        public static final int CUSTOMER = 1;
        public static final int PRODUCT = 2;
        public static final int CURRENCY = 3;
        public static final int LIMIT = 4;
        public static final int EXPIRY = 5;
        public static final int LIMIT_TYPE = 6;
        public static final int LIMIT_PORTFOLIO = 7;
        public static final int ORGANIZATION_CODE = 8;
        public static final int LIMIT_MEASURE = 9;
        public static final int LIMIT_TENOR = 10;
        public static final int LIMIT_STEP_NO = 11;
        public static final String LIMIT_TENOR_DATE_FORMAT="dd/MM/yyyy";
        public static final String LIMIT_FACILITY_TYPE = "Import Letter of Credit";
        public static final String NORMAL_LIMIT_TYPE = "Normal";
    }

    // public static final String FILENAME_HEADER = "FileHeaders.FILENAME";

    public static final String VOUCHER_ALL = "A";

    public interface SwiftMTConstants{
        public static final String MT7XX_EMAIL = "MT7XX_EMAIL:REQUEST";
        public static final String MT7XX_EMAIL_DOC_DESC ="Inward message ";
        public static final String MT101_DOC_DESC ="MT101 Payment Instructions";
        public static final String MT101_MSG_BODY = "Please find attached your MT101 Payment Instructions.<br/><br/><br/>";
        public static final int ACCOUNT_NUMBER = 0;
        public static final int NOT_ACCOUNT_NUMBER = 1;
        public static final String SMS_PROCESS = "SMS:PROCESS";
        public static final String MT103_FOLLOW_UP_PROCESS = "MT103_FOLLOW_UP:PROCESS";
        public static final String MT103_CHANNEL_REQUEST = "MT103_CHANNEL:REQUEST";
        public static final String GPI_UPDATE_REQUEST = "GPI_UPDATE:REQUEST";
        public static final String GPI_FINAL_STATUS_NOTIFY = "GPI:FINAL_STATUS:NOTIFY";
        public static final String SWIFT_FAILURE_PROCESS = "SWIFT_FAILURE:PROCESS";
        public static final String GPI_SRP_PROCESS = "GPI_SRP:PROCESS";
        public static final String MT103_EMAIL_PROCESS = "MT103_EMAIL:PROCESS";
        public static final String MT192_REQUEST = "MT192:REQUEST";

        public static final String SWIFT_DATE_PATTERN = "yyMMdd";
        public static final String EE_DATE_PATTERN = "yyyy-MM-dd";
        public static final String GPI_DATE_PATTERN = "yyyyMMdd";
        public static final String ACCOUNT_NOT_FOUND = "000000000";
    }

    public interface SwiftMessageTypes{
        public static final String MT700 = "700";
        public static final String MT754 = "754";
        public static final String MT769 = "769";
        public static final String MT103 = "103";
        public static final String MT199 = "199";
        public static final String MT202 = "202";
        public static final String MT101 = "101";
        public static final String MT710 = "710";
        public static final String MT720 = "720";
        public static final String MT701 = "701";
        public static final String MT711 = "711";
        public static final String MT721 = "721";
        public static final String MT792 = "792";
        public static final String MT191 = "191";
        public static final String MT450 = "450";
        public static final String MT456 = "456";
        public static final String MT798 = "798";
        public static final String MT799 = "799";
        public static final String MT420 = "420";
        public static final String MT499 = "499";
        public static final String MT192 = "192";
        public static final String MT707 = "707";
        public static final String MT708 = "708";
        public static final String MT730 = "730";
        public static final String MT760 = "760";
        public static final String MT765 = "765";
        public static final String MT768 = "768";
        public static final String MT791 = "791";
        public static final String MT752 = "752";
        public static final String MT759 = "759";
        public static final String MT756 = "756";
        public static final String MT742 = "742";
    }

    public interface MTTAGS {
        public static final int FIELD_21F_COVNO_END = 9;
        public static final int FIELD_21F_COVNO_START = 0;
        public static final String MESSAGE_STRING = "MessageString";
        public static final String FIELD_77B = "77B";
        public static final String FIELD_71A = "71A";
        public static final String FIELD_23E = "23E";
        public static final String FIELD_70 = "70";
        public static final String FIELD_52A = "52A";
        public static final String PRIORITY_URGENT = "Urgent";
        public static final String PRIORITY_NORMAL = "Normal";
        public static final String PAID_AT_WAIVED = "WAIVED";
        public static final String CASH_INDICATOR_NO = "No";
        public static final String CASH_INDICATOR_YES = "Yes";
        public static final String CHANNEL_SINGLE = "MT101";
        public static final String CHANNEL_MULTI = "MT101 Multi";
        public static final String FIELD_57A = "57A";
        public static final String FIELD_21 = "21";
        public static final String FIELD_32B = "32B";
        public static final String FIELD_21R = "21R";
        public static final String FIELD_28D = "28D";
        public static final String FIELD_30 = "30";
        public static final String FIELD_50H = "50H";
        public static final String FIELD_58A = "58A";
        public static final String FIELD_59 = "59";
        public static final String FIELD_59F = "59F";
        public static final int DEBIT_ACCOUNT = 0;
        public static final int CREDIT_ACCOUNT = 1;
        public static final String FIELD_20 = "20";
        public static final String FIELD_21E = "21E";
        public static final String FIELD_36 = "36";
        public static final String FIELD_21F = "21F";
        public static final int FIELD_32B_AMOUNT_START = 3;
        public static final int FIELD_32B_CCY_START = 0;
        public static final int FIELD_32B_CCY_END = 3;
        public static final String FIELD_49 = "49";
        public static final String FIELD_76 = "76";
        public static final String FIELD_75 = "75";
        public static final String FIELD_11S = "11S";
        public static final String FIELD_34A = "34A";
        public static final String FIELD_23 = "23";
        public static final String FIELD_33A = "33A";
        public static final String FIELD_79 = "79";
        public static final String FIELD_77E = "77E";
        public static final String FIELD_40F = "40F";
        public static final String FIELD_12 = "12";
        public static final String FIELD_41A = "41A";
        public static final String FIELD_41D = "41D";
        public static final String FIELD_32A = "32A";
        public static final String FIELD_31C = "31C"; //issue date
        public static final String FIELD_40A = "40A"; //lc type 700
        public static final String FIELD_40B = "40B"; //lc type 720
        public static final String FIELD_27 = "27"; //lc type 720
        public static final String FIELD_108 = "108"; //lc type 720
        public static final String FIELD_33B = "33B"; //fog mt768
        public static final String FIELD_59A = "59A";
        public static final String FIELD_50F = "50F";
        public static final String FIELD_50G = "50G";
        public static final String ZDS = "ZDS";
        public static final String SRS = "SRS";
        public static final String TIS = "TIS";
        public static final String FIELD_103 = "103";
        public static final String FIELD_72 = "72"; //zds
        public static final String FIELD_119 = "119"; //cover
        public static final String FIELD_71F = "71F";
        public static final String FIELD_71G = "71G";
        public static final String FIELD_50K = "50K";
        public static final String FIELD_57B = "57B";
        public static final String FIELD_57C = "57C";
        public static final String FIELD_57D = "57D";
        public static final String FIELD_53A = "53A";
        public static final String FIELD_54A = "54A";
        public static final String FIELD_50A = "50A";
        public static final String FIELD_111 = "111";
        public static final String FIELD_121 = "121";
        public static final String MT_199 = "MT199";
        public static final String MT_196 = "MT196";
    }

    public interface MetroConstants{
        public static final String METRO_RATE_FEED_MSG = "<ser:getRateFeed xmlns:ser=\"http://service.serverapi.dealrouting.gmt.sbsa/\" />";
        public static final String METRO_OPEN_MSG = "<NS1:getRateFeedResponse";
        public static final String METRO_CLOSE_MSG = "</NS1:getRateFeedResponse>";
        public static final String METRO_XMLNS =  "xmlns:NS1=\"http://service.serverapi.dealrouting.gmt.sbsa/\">";
        public static final String METRO_XMLNS_ENCODING = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
        public static final String METRO_RETURN = "return>";
        public static final String METRO_RATE_FEED = "MetroRateFeed>";
        public static final String METRO_FEED_LIST_OPEN = "<metroFeedList>";
        public static final String METRO_FEED_LIST_CLOSE = "</metroFeedList>";
        public static final String METRO_SOURCE = "METRO";
        public static final String METRO_UNIT_CODE = "00";
        public static final String METRO_COUNTRY_CODE = "ZA";
        public static final String METRO_CURRENCY_GROUP_NAME_ZA = "Standard Bank South Africa - Buy/Sell Rates";
        public static final String METRO_BUYING_RATE = "TT Buying";
        public static final String METRO_MID_RATE = "Booking Rate";
        public static final String METRO_SELLING_RATE = "TT Selling";
        public static final String METRO_PROC_CENTER = "C";
        public static final String METRO_TIER = "EE";
        public static final String METRO_CHANNEL = "EE";

    }

    public interface CreditManagement{
        public static final String ADAPTIVE_SOURCE = "Adaptive";
        public static final String ADAPTIV_SOURCE = "Adaptiv";
        public static final String ECUBE_SOURCE = "Ecube";
        public static final String BOOKING_RATE = "Booking Rate";
        public static final String ECUBE_RATE = "Booking Rate";
        public static final String EXPOSURE_QUERY= "supportDataDao-exposureRequest.sql";
        public static final String ZA_EXPOSURE_QUERY= "supportDataDao-exposureZARequest.sql";
        public static final String FACILITY_TYPE = "Import Letter of Credit";

        public interface Exposures{
            public static final int LM_CUST_ID = 0;
            public static final int PARTY_NM = 1;
            public static final int C_UNIT_CODE = 2;
            public static final int LM_FACI_ID = 3;
            public static final int LM_TRX_REF = 4;
            public static final int LM_TRX_CCY = 5;
            public static final int LM_DUE_DAY = 6;
            public static final int LM_TRX_AMT = 7;
            public static final int LM_DATE_STMP = 8;
            public static final int LM_PME_FLAG = 9;
            public static final int LM_SUB_CCY = 10;
            public static final int LM_CRED_LMT = 11;
            public static final int REV_TYPE = 12;
            public static final int EXPOSURE_AMOUNT = 13;
            public static final int F_VALUE = 14;
            public static final int LM_MAKE_BY = 15;
            public static final int APPL_BK_AC_NO = 16;
            public static final int MKT_SEG_CODE = 17;
            public static final int CHG_POLICY_AMT = 18;
            public static final int LM_CL_CODE = 19;
            public static final int LM_TRX_CODE = 20;
            public static final String TABLE_39_ITEM_NAME_1000000001 = "1000000001";
            public static final String TABLE_39_ITEM_NAME_1000000005 = "1000000005";
            public static final String TABLE_39_ITEM_NAME_1000000006 = "1000000006";
            public static final String DEFAULT_MKT_SEG_CODE= "130";

        }
    }

    public interface SpawnedProcesses{
        String GE_TRANS_PROCESS = "GE_TRANS:PROCESS";
        String RELEASE_TRN_SCF_REPORT_GENERATION = "ReleaseTrnScfReportGeneration";
        String EXPOSURE_PROCESS = "EXPOSURE:PROCESS";
        String DIRECT_LIABILITY_PROCESS = "DIRECT_LIABILITY:PROCESS";
        String CONTINGENT_PROCESS = "CONTINGENT:PROCESS";
        String COMMISSION_PROCESS = "COMMISSION:PROCESS";
        String COMMISSION_DIARY = "COMMISSION:DIARY";
        String CHANNEL_UPDATE_PROCESS = "CHANNEL_UPDATE:PROCESS";
        String CFC_ENTRY_RESPONSE = "CFC_ENTRY:RESPONSE";
        String CFC_REVERSE_REQUEST = "CFC_REVERSE:REQUEST";
        String CFC_REVERSE_RESPONSE = "CFC_REVERSE:RESPONSE";
        String BOP_CREATE_PROCESS = "BOP_CREATE:PROCESS";
        String PBB_PROCESS = "PBB:PROCESS";
        String PBB_EARMARK_PROCESS = "PBB_EARMARK:PROCESS";
        String CIB_PROCESS = "CIB:PROCESS";
        String OSM_PROCESS = "OSM:PROCESS";
        String OSM_CE_PROCESS = "OSM_CE:PROCESS";
        String OSM_CE_REQUEST = "OSM_CE:REQUEST";
        String PRINT_REQUEST = "PRINT:REQUEST";
        String FORM_M_PROCESS = "FORM_M:PROCESS";
        String FORM_M_RESPONSE = "FORM_M:RESPONSE";
        String FORM_M_CREATE_REQUEST = "FORM_M_CREATE:REQUEST";
        String FORM_M_UPDATE_REQUEST = "FORM_M_UPDATE:REQUEST";
        String EARLY_USANCE_PROCESS = "EARLY_USANCE:PROCESS";
        String FTP_REQUEST = "FTP:REQUEST";
        String DTRES_PROCESS = "DTRES:PROCESS";
        String DTRES_REQUEST = "DTRES:REQUEST";
        String DTRES_RESPONSE = "DTRES:RESPONSE";
        String NBOL_DOC_REQUEST = "NBOL_DOC:REQUEST";
        String BRIDGE_EXCHANGE_RATE = "EXCHANGE_RATE_BRIDGE:REQUEST";
        String METRO_EXCHANGE_RATE = "EXCHANGE_RATE_METRO:REQUEST";
        String EXCHANGE_TRIGGER = "EXCHANGE_RATE:TRIGGER";String EXCHANGE_RATE_CROSS_CURRENCY_UPDATE = "EXCHANGE_RATE_CROSS_CURRENCY:UPDATE";
        String DOC_CIB_SHAREPOINT_PROCESS = "DOC_CIB_SHAREPOINT:PROCESS";
        String WEB_DAV_PUT = "WEB_DAV:PUT";
        String SSI_PROCESS = "SSI:PROCESS";
        String DATA_MINING_FAEF_PROCESS = "DATA_MINING_FAEF:PROCESS";
        String GPI_PROCESS = "GPI:PROCESS";
        String EXCHANGE_RATE_BRIDGE_UPDATE = "EXCHANGE_RATE_BRIDGE:UPDATE";
        String EXCHANGE_RATE_BRIDGE_REQUEST = "EXCHANGE_RATE_BRIDGE:REQUEST";
        String QUEUE_IN_ROBUSTA_TO_BRIDGE = "MESSAGE:IN:ROBUSTA_TO_BRIDGE";
        String QUEUE_OUT_BRIDGE_TO_ROBUSTA = "MESSAGE:OUT:BRIDGE_TO_ROBUSTA";
        String ROBUSTA_STATUS_UPDATE = "ROBUSTA:STATUS:UPDATE";
        String MOCHA_STATUS_UPDATE = "MOCHA:STATUS:UPDATE";
        String LCIR_EE_TO_CE_REQUEST = "LCIR:EE_TO_CE:CREATE:REQUEST";
        String LCIR_EE_TO_CE_DOC_REQUEST = "LCIR:EE_TO_CE:DOC:REQUEST";
        String EBANKING_OPERATOR_NOTIFY = "EBANKING:OPERATOR:NOTIFY";
        String EBANKING_REQUEST = "EBANKING:REQUEST";
        String EBANKING_RESPONSE = "EBANKING:RESPONSE";
        String EBANKING_UPDATE = "EBANKING:UPDATE";
        String PYID_REQUEST = "PYID:REQUEST";
        String ROBUSTA_PROCESS = "ROBUSTA:PROCESS";
        String MARU_STATUS_UPDATE = "MARU:STATUS:UPDATE";
    }

    public interface BopCancelReplaceProcess{
        public static final String BOP_CR_PROCESS = "BOP_CR:PROCESS";
        public static final String BOP_CR_CREATE_PROCESS = "BOP_CR_CREATE:PROCESS";
    }

    public interface CIFBridgeRequest {
        public static final String CIF_BRIDGE_REQUEST = "CIF:BRIDGE:REQUEST";
    }

    public interface CFuncShortName {
        public static final String CANCEL_ITT = "Cancel_ITT";
        public static final String PROC_INC_103 = "Proc_Inc_103";
        public static final String ITT_REC_ADD_CHGS = "ITTRecAddChgs";
        public static final String INMT_10X = "INMT10X";
        public static final String INMT_103 = "INMT103";
        public static final String AUTO_ACCEPT = "Auto_Acceptance";
        public static final String AUTO_IMCO_DP_PAYMENT = "Auto_IMCO_DPPayment";
        public static final String CLSELC = "CLSELC";
    }

    public interface CEventName {
        public static final String INWARD_PAYMENTS = "Inward Payments";
        public static final String IMLC_DOC_CHECK = "IMLC DocCheck";
        public static final String IMLC_PAY_ACCEPT = "IMLC Pay/Accpt";
    }

    public interface TransactionStatus {
        public static final String M = "M";
        public static final String P = "P";
    }

    public interface PurposeCode {
        public static final String PENSION = "PENSION";
        public static final String SB_PENSION = "Standard Bank Pension";
    }

    public interface OrderLine {
        public static final String SINGLE_SETTLEMENT = "Single Settlement";
        public static final String FORWARD_FUNDS = "Forward Funds";
        public static final String RETURN_OF_FUNDS = "Return of Funds";
    }

    public interface SwiftCodeWords {
        public static final String DUPL = "DUPL";
        public static final String AGNT = "AGNT";
        public static final String CURR = "CURR";
        public static final String CUST = "CUST";
        public static final String UPAY = "UPAY";
        public static final String CUTA = "CUTA";
        public static final String TECH = "TECH";
        public static final String FRAD = "FRAD";
        public static final String COVR = "COVR";
        public static final String AMNT = "AMNT";
    }

    public interface PaymentNextStatus {
        public static final String ITT_RELEASE = "ITT_RELEASE";
        public static final String ITT_REVERSE_RELEASE = "ITT_REVERSE_RELEASE";
        public static final String GEN_ACCT_RELEASE = "GEN_ACCT_RELEASE";
        public static final String OTT_RELEASE = "OTT_RELEASE";
        public static final String INTERNAL_TRANSFER_RELEASE = "INTERNAL_TRANSFER_RELEASE";
        public static final String END = "END";
    }

    public interface MochaToCE {
        public static final String STP_IN_IMG = "STP_IN_IMG";
        public static final String IMLC_STP_FUNC_ID = "F05030700829";
        public static final String IMLC_STP_FUNC_NAME = "Apply for Import LC";
        public static final String CNTY_CODE_US = "US";
        public static final String DOC_TYPE = "form";

        public static final String IMAGE_MODULE = "IMLC";
        public static final String IMAGE_DESC = "Mocha API";
        public static final String IMG_SUPPORT_DOC = "Supp Docs";
    }
}
