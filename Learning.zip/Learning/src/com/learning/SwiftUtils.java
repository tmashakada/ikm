package com.learning;

import org.apache.commons.lang3.StringUtils;

public class SwiftUtils {
  public static String getCountryFromBic(String bic) {
    return StringUtils.substring(bic, AccConstants.NbolConstants.COUNTRY_CODE_SUBSTRING_START, AccConstants.NbolConstants.COUNTRY_CODE_SUBSTRING_END);
  }
}
