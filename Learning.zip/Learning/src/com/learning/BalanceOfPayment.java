package com.learning;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("BalanceOfPayment")
public class BalanceOfPayment extends BopDetails{
    @XStreamAlias("Code")
    private String code;

    @XStreamAlias("bopDescription")
    private String bopDescription;

    @XStreamAlias("LibraData")
    private String libraData;

    public void setCode(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }
    public String getBopDescription() {
        return bopDescription;
    }

    public void setBopDescription(String bopDescription) {
        this.bopDescription = bopDescription;
    }

    public String getLibraData() {
        return libraData;
    }

    public void setLibraData(String libraData) {
        this.libraData = libraData;
    }
}
