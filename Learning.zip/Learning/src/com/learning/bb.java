package com.learning;

public class bb {
  public  static  void  main(String [] arc){

  }


}
