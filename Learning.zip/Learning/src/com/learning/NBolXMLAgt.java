package com.learning;

import com.thoughtworks.xstream.annotations.XStreamAlias;

/**
 *
 * @author Herman Sheppard
 *
 * XStream object wrapping for XML received from nBol.
 *
 */

@XStreamAlias("Agt")
public class NBolXMLAgt {

    @XStreamAlias("FinInstnId")
    private NBolXMLFinancialInstitutionId financialInstitutionId;

    @XStreamAlias("BrnchId")
    private NBolXMLBranchId branchId;

    public void setFinancialInstitutionId(NBolXMLFinancialInstitutionId financialInstitutionId) {
        this.financialInstitutionId = financialInstitutionId;
    }

    public NBolXMLFinancialInstitutionId getFinancialInstitutionId() {
        return financialInstitutionId;
    }

    public void setBranchId(NBolXMLBranchId branchId) {
        this.branchId = branchId;
    }

    public NBolXMLBranchId getBranchId() {
        return branchId;
    }
}
