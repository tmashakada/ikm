package com.learning;


import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("LegalEntityType")
public class NBolXMLLegalEntityType extends BaseObject{
    @XStreamAlias("TradingName")
    private String tradingName;

    @XStreamAlias("RegistrationNumber")
    private String registrationNumber;

    @XStreamAlias("InstitutionalSector")
    private String institutionalSector;

    @XStreamAlias("IndustrialClasssification")
    private String industrialClasssification;

    public String getTradingName() {
        return tradingName;
    }

    public void setTradingName(String tradingName) {
        this.tradingName = tradingName;
    }

    public String getRegistrationNumber() {
        return registrationNumber;
    }

    public void setRegistrationNumber(String registrationNumber) {
        this.registrationNumber = registrationNumber;
    }

    public String getInstitutionalSector() {
        return institutionalSector;
    }

    public void setInstitutionalSector(String institutionalSector) {
        this.institutionalSector = institutionalSector;
    }

    public String getIndustrialClasssification() {
        return industrialClasssification;
    }

    public void setIndustrialClasssification(String industrialClasssification) {
        this.industrialClasssification = industrialClasssification;
    }


}
