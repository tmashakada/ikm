package com.learning;

import com.thoughtworks.xstream.annotations.XStreamAlias;

public class AdHoc extends BaseObject {
    @XStreamAlias("adHocSubject")
    private String adHocSubject;
    @XStreamAlias("description")
    private String description;


    public String getAdHocSubject() {
        return adHocSubject;
    }

    public void setAdHocSubject(String adHocSubject) {
        this.adHocSubject = adHocSubject;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
