package com.learning;

import com.thoughtworks.xstream.annotations.XStreamAlias;

/**
 *
 * @author Herman Sheppard
 *
 * XStream object wrapping for XML received from nBol.
 *
 */

@XStreamAlias("PstlAdr")
public class NBolXMLPostalAddress {

    @XStreamAlias("AdrLine")
    private String addressLine;

    @XStreamAlias("StrtNm")
    private String streetName;

    @XStreamAlias("PstCd")
    private String postalCode;

    @XStreamAlias("TwnNm")
    private String townName;

    @XStreamAlias("CtrySubDvsn")
    private String countrySubDivision;

    @XStreamAlias("Ctry")
    private String country;

    public void setAddressLine(String addressLine) {
        this.addressLine = addressLine;
    }

    public String getAddressLine() {
        return addressLine;
    }

    public void setStreetName(String streetName) {
        this.streetName = streetName;
    }

    public String getStreetName() {
        return streetName;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setTownName(String townName) {
        this.townName = townName;
    }

    public String getTownName() {
        return townName;
    }

    public void setCountrySubDivision(String countrySubDivision) {
        this.countrySubDivision = countrySubDivision;
    }

    public String getCountrySubDivision() {
        return countrySubDivision;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCountry() {
        return country;
    }
}
