package com.learning;


import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("EntityTypeDetails")
public class NBolXMLEntityTypeDetails extends BaseObject{

    @XStreamAlias("IndividualType")
    private NBolXMLIndividualType individual;

    @XStreamAlias("LegalEntityType")
    private NBolXMLLegalEntityType legalEntity;

    @XStreamAlias("ExceptionType")
    private NBolXMLExceptionType exception;

    public NBolXMLIndividualType getIndividual() {
        return individual;
    }

    public void setIndividual(NBolXMLIndividualType individual) {
        this.individual = individual;
    }

    public NBolXMLLegalEntityType getLegalEntity() {
        return legalEntity;
    }

    public void setLegalEntity(NBolXMLLegalEntityType legalEntity) {
        this.legalEntity = legalEntity;
    }

    public NBolXMLExceptionType getException() {
        return exception;
    }

    public void setException(NBolXMLExceptionType exception) {
        this.exception = exception;
    }


}

