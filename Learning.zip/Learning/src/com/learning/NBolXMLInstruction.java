package com.learning;


import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import java.util.List;

/**
 * @author Herman Sheppard
 *         <p/>
 *         XStream object wrapping for XML received from nBol.
 */

public class NBolXMLInstruction extends BaseObject {

    private static final long serialVersionUID = -3045472723367491200L;

    @XStreamAlias("InstrId")
    private String instructionId;

    @XStreamAlias("InstrmtClsfctn")
    private String instrmtClsfctn;

    @XStreamAlias("ReqdExctnDt")
    private String requiredExecutionDate;

    @XStreamAlias("CreationDate")
    private String creationDate;

    @XStreamAlias("CustomerContactPerson")
    private String customerContactPerson;

    @XStreamAlias("CustomerContactNumber")
    private String customerContactNumber;

    @XStreamAlias("UserEmailId")
    private String userEmailId;

    @XStreamImplicit(itemFieldName = "ProcessingOption")
    private List<NBolXMLProcessingOption> nBolProcessingOption;

    @XStreamImplicit(itemFieldName = "Trn")
    private List<NBolXMLTransaction> nBolTransaction;

    public void setInstructionId(String instructionId) {
        this.instructionId = instructionId;
    }

    public String getInstructionId() {
        return instructionId;
    }

    public void setnBolTransaction(List<NBolXMLTransaction> nBolTransaction) {
        this.nBolTransaction = nBolTransaction;
    }

    public List<NBolXMLTransaction> getnBolTransaction() {
        return nBolTransaction;
    }

    public void setInstrmtClsfctn(String instrmtClsfctn) {
        this.instrmtClsfctn = instrmtClsfctn;
    }

    public String getInstrmtClsfctn() {
        return instrmtClsfctn;
    }

    public void setRequiredExecutionDate(String requiredExecutionDate) {
        this.requiredExecutionDate = requiredExecutionDate;
    }

    public String getRequiredExecutionDate() {
        return requiredExecutionDate;
    }

    public void setCreationDate(String creationDate) {
        this.creationDate = creationDate;
    }

    public String getCreationDate() {
        return creationDate;
    }

    public void setnBolProcessingOption(List<NBolXMLProcessingOption> nBolProcessingOption) {
        this.nBolProcessingOption = nBolProcessingOption;
    }

    public List<NBolXMLProcessingOption> getnBolProcessingOption() {
        return nBolProcessingOption;
    }

    public void setCustomerContactPerson(String customerContactPerson) {
        this.customerContactPerson = customerContactPerson;
    }

    public String getCustomerContactPerson() {
        return customerContactPerson;
    }

    public void setCustomerContactNumber(String customerContactNumber) {
        this.customerContactNumber = customerContactNumber;
    }

    public String getCustomerContactNumber() {
        return customerContactNumber;
    }

    public String getUserEmailId() {
        return userEmailId;
    }

    public void setUserEmailId(String userEmailId) {
        this.userEmailId = userEmailId;
    }
}
