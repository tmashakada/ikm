package com.learning;

import com.thoughtworks.xstream.converters.Converter;
import com.thoughtworks.xstream.converters.MarshallingContext;
import com.thoughtworks.xstream.converters.UnmarshallingContext;
import com.thoughtworks.xstream.io.HierarchicalStreamReader;
import com.thoughtworks.xstream.io.HierarchicalStreamWriter;

/**
 *
 * @author Herman Sheppard
 *
 * The NBolXMLCurrencyAmountConverter class is a supporter class to the NBolXMLCurrencyAmount class enabelling XStrem to marshal/unmarshal
 * the received tag containing an attribute and a value.
 *
 */

public class NBolXMLCurrencyAmountConverter implements Converter {

    public void marshal(Object value, HierarchicalStreamWriter writer, MarshallingContext context) {
        NBolXMLCurrencyAmount currencyAmount = (NBolXMLCurrencyAmount) value;
        writer.addAttribute("Ccy", currencyAmount.getCcy());
        writer.setValue(currencyAmount.getValue());
    }


    public boolean canConvert(Class clazz) {
        return clazz.equals(NBolXMLCurrencyAmount.class);
    }


    public Object unmarshal(HierarchicalStreamReader reader,
                            UnmarshallingContext context) {
        NBolXMLCurrencyAmount currencyAmount = new NBolXMLCurrencyAmount();
        currencyAmount.setCcy(reader.getAttribute("Ccy"));
        currencyAmount.setValue(reader.getValue());
        return currencyAmount;
    }
}

