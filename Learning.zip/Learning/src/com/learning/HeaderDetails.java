package com.learning;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("headerDetails")
public class HeaderDetails extends BaseObject {

    private String partyIdentifier;
    private String entityTypeName;
    private String resident;
    private String surname;
    private String name;
    private String tradingName;
    private String institutionalSector;
    private String industrialClassification;
    private String gender;
    private String dateOfBirth;
    private String idNumber;
    private String tempResPermitNumber;
    private String foreignIdNumber;
    private String foreignIdCountry;
    private String passportNumber;
    private String passportCountry;
    private String nm;
    private String accountIdentifier;
    private String id;
    private String taxNumber;
    private String vatNumber;
    private String taxClearenceIndicator;
    private String taxClearenceReference;
    private String customsClientNumber;
    private String country;
    private String registrationNumber;

    @XStreamAlias("ContactPerson")
    private NBolXMLContactPerson contactPerson;

    @XStreamAlias("address")
    private ResidentialAddress address;


    public String getPartyIdentifier() {
        return partyIdentifier;
    }

    public void setPartyIdentifier(String partyIdentifier) {
        this.partyIdentifier = partyIdentifier;
    }

    public String getEntityTypeName() {
        return entityTypeName;
    }

    public void setEntityTypeName(String entityTypeName) {
        this.entityTypeName = entityTypeName;
    }

    public String getResident() {
        return resident;
    }

    public void setResident(String resident) {
        this.resident = resident;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTradingName() {
        return tradingName;
    }

    public void setTradingName(String tradingName) {
        this.tradingName = tradingName;
    }

    public String getInstitutionalSector() {
        return institutionalSector;
    }

    public void setInstitutionalSector(String institutionalSector) {
        this.institutionalSector = institutionalSector;
    }

    public String getIndustrialClassification() {
        return industrialClassification;
    }

    public void setIndustrialClassification(String industrialClassification) {
        this.industrialClassification = industrialClassification;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getIdNumber() {
        return idNumber;
    }

    public void setIdNumber(String idNumber) {
        this.idNumber = idNumber;
    }

    public String getTempResPermitNumber() {
        return tempResPermitNumber;
    }

    public void setTempResPermitNumber(String tempResPermitNumber) {
        this.tempResPermitNumber = tempResPermitNumber;
    }

    public String getForeignIdNumber() {
        return foreignIdNumber;
    }

    public void setForeignIdNumber(String foreignIdNumber) {
        this.foreignIdNumber = foreignIdNumber;
    }

    public String getForeignIdCountry() {
        return foreignIdCountry;
    }

    public void setForeignIdCountry(String foreignIdCountry) {
        this.foreignIdCountry = foreignIdCountry;
    }

    public String getPassportNumber() {
        return passportNumber;
    }

    public void setPassportNumber(String passportNumber) {
        this.passportNumber = passportNumber;
    }

    public String getPassportCountry() {
        return passportCountry;
    }

    public void setPassportCountry(String passportCountry) {
        this.passportCountry = passportCountry;
    }

    public String getNm() {
        return nm;
    }

    public void setNm(String nm) {
        this.nm = nm;
    }

    public String getAccountIdentifier() {
        return accountIdentifier;
    }

    public void setAccountIdentifier(String accountIdentifier) {
        this.accountIdentifier = accountIdentifier;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTaxNumber() {
        return taxNumber;
    }

    public void setTaxNumber(String taxNumber) {
        this.taxNumber = taxNumber;
    }

    public String getVatNumber() {
        return vatNumber;
    }

    public void setVatNumber(String vatNumber) {
        this.vatNumber = vatNumber;
    }

    public String getTaxClearenceIndicator() {
        return taxClearenceIndicator;
    }

    public void setTaxClearenceIndicator(String taxClearenceIndicator) {
        this.taxClearenceIndicator = taxClearenceIndicator;
    }

    public String getTaxClearenceReference() {
        return taxClearenceReference;
    }

    public void setTaxClearenceReference(String taxClearenceReference) {
        this.taxClearenceReference = taxClearenceReference;
    }

    public String getCustomsClientNumber() {
        return customsClientNumber;
    }

    public void setCustomsClientNumber(String customsClientNumber) {
        this.customsClientNumber = customsClientNumber;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getRegistrationNumber() {
        return registrationNumber;
    }

    public void setRegistrationNumber(String registrationNumber) {
        this.registrationNumber = registrationNumber;
    }

    public NBolXMLContactPerson getContactPerson() {
        return contactPerson;
    }

    public void setContactPerson(NBolXMLContactPerson contactPerson) {
        this.contactPerson = contactPerson;
    }

    public ResidentialAddress getAddress() {
        return address;
    }

    public void setAddress(ResidentialAddress address) {
        this.address = address;
    }

}
