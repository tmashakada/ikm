package com.learning;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Set;

public class TestPerce {
  public static  void main(String [] args){
   final BigDecimal SAVINGS_ACCOUNT_INTEREST_PERC=new BigDecimal("0.005");
    final BigDecimal amount=new BigDecimal("1000.00");
   BigDecimal result=amount.multiply(SAVINGS_ACCOUNT_INTEREST_PERC);
   System.out.println(result);;
    // Create a HashSet object and initialize it
    Set<String> cities_Set = new HashSet<String>();
 int j=0;
   for(int i=0;i<10000;i++){
     j++;
     String lastpart=new SimpleDateFormat("ss").format(Calendar.getInstance().getTime());
     int number= (int)(Math.random()*90000000)+10000000;
     String bb=number+lastpart;
     cities_Set.add(bb);
     System.out.println(j+" "+number+" "+lastpart);;

   }
    // Print the set contents
    System.out.println("HashSet: "+cities_Set.size());
    int number= (int)(Math.random()*90000000)+10000000;
    System.out.println("HashSet: "+number);
  }
}
