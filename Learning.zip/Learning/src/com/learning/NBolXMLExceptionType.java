package com.learning;


import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("ExceptionType")
public class NBolXMLExceptionType extends BaseObject{
    @XStreamAlias("ExceptionCountry")
    private String exceptionCountry;


}