package com.learning;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("BAN") // another mapping
public class Ban {

    /*
     We want to have different field names in Java classes so
     we define what element should be mapped to each field
    */
    @XStreamAlias("UPDATED_AT") //
    private String dateOfUpdate;

    @XStreamAlias("TROUBLEMAKER")
    private Person person;

    public Ban() {
    }

    public String getDateOfUpdate() {
        return dateOfUpdate;
    }

    public void setDateOfUpdate(String dateOfUpdate) {
        this.dateOfUpdate = dateOfUpdate;
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }
}
