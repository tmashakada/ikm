package com.learning;

public  final class EEProductEntityUtil {
  public static final String MODULE_INTR = "INTR";
  public static final String PRODUCT_IT = "IT";
  public static final String PRODUCT_AT = "AT";
  private EEProductEntityUtil() {

  }
}
