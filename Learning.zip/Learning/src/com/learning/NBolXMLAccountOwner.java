package com.learning;

import com.thoughtworks.xstream.annotations.XStreamAlias;

/**
 *
 * @author Herman Sheppard
 *
 * XStream object wrapping for XML received from nBol.
 *
 */

@XStreamAlias("AcctOwner")
public class NBolXMLAccountOwner {

    @XStreamAlias("Nm")
    private String name;

    @XStreamAlias("PstlAdr")
    private NBolXMLPostalAddress postalAddress;

    @XStreamAlias("Id")
    private NBolXMLAccountOwnerId id;

    @XStreamAlias("Lmt")
    private NBolXMLAccountOwnerLimit limit;

    @XStreamAlias("Resident")
    private String resident;

    @XStreamAlias("Address")
    private NBolXMLStreetAddress streetAddress;

    @XStreamAlias("ContactPerson")
    private NBolXMLContactPerson contactPerson;

    @XStreamAlias("Entity")
    private NBolXMLEntity entity;

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setPostalAddress(NBolXMLPostalAddress postalAddress) {
        this.postalAddress = postalAddress;
    }

    public NBolXMLPostalAddress getPostalAddress() {
        return postalAddress;
    }

    public void setId(NBolXMLAccountOwnerId id) {
        this.id = id;
    }

    public NBolXMLAccountOwnerId getId() {
        return id;
    }

    public void setLimit(NBolXMLAccountOwnerLimit limit) {
        this.limit = limit;
    }

    public NBolXMLAccountOwnerLimit getLimit() {
        return limit;
    }
    public String getResident() {
        return resident;
    }

    public void setResident(String resident) {
        this.resident = resident;
    }

    public NBolXMLStreetAddress getStreetAddress() {
        return streetAddress;
    }

    public void setStreetAddress(NBolXMLStreetAddress streetAddress) {
        this.streetAddress = streetAddress;
    }

    public NBolXMLContactPerson getContactPerson() {
        return contactPerson;
    }

    public void setContactPerson(NBolXMLContactPerson contactPerson) {
        this.contactPerson = contactPerson;
    }

    public NBolXMLEntity getEntity() {
        return entity;
    }

    public void setEntity(NBolXMLEntity entity) {
        this.entity = entity;
    }


}
