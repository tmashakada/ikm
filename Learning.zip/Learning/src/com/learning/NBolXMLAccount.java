package com.learning;

import com.thoughtworks.xstream.annotations.XStreamAlias;

/**
 *
 * @author Herman Sheppard
 *
 * XStream object wrapping for XML received from nBol.
 *
 */

@XStreamAlias("Acct")
public class NBolXMLAccount {

    @XStreamAlias("AcctId")
    private NBolXMLAccountId accountId;

    @XStreamAlias("Tp")
    private String tp;

    @XStreamAlias("Ccy")
    private String currencyCode;

    @XStreamAlias("Nm")
    private String name;

    @XStreamAlias("AccountIdentifier")
    private String accountIdentifier;

    public void setAccountId(NBolXMLAccountId accountId) {
        this.accountId = accountId;
    }

    public NBolXMLAccountId getAccountId() {
        return accountId;
    }

    public void setTp(String tp) {
        this.tp = tp;
    }

    public String getTp() {
        return tp;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public String getAccountIdentifier() {
        return accountIdentifier;
    }

    public void setAccountIdentifier(String accountIdentifier) {
        this.accountIdentifier = accountIdentifier;
    }
}
