package com.learning;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("CorrespondingAgt")
public class NBolXMLCorrespondingAgt {

    @XStreamAlias("FinInstnId")
    private NBolXMLFinancialInstitutionId financialInstitutionId;

    public NBolXMLFinancialInstitutionId getFinancialInstitutionId() {
        return financialInstitutionId;
    }

    public void setFinancialInstitutionId(
            NBolXMLFinancialInstitutionId financialInstitutionId) {
        this.financialInstitutionId = financialInstitutionId;
    }
}