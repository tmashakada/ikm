package com.learning;

import java.util.HashMap;
import java.util.Map;

public class MapUpdateTest {


    public static void main(String[] args) {

        int [] inputArray={6,6,6,1,1,17,17,5,5,5,5,5,4,3,9};
        arrayElementCount( inputArray);

    }
    public static  void modifyMap(){
        HashMap<String, String> map = new HashMap<>();
        map.put("Tafadzwa", "Mashakada");
        map.put("Musa", "Moyo");
        map.put("Test", "Kim");
        for(Map.Entry<String,String> entry : map.entrySet()){
            System.out.println("[Key] : " + entry.getKey() + " [Value] : " + entry.getValue());
        }
        System.out.println("=================================================");
        for(Map.Entry<String,String> entry : map.entrySet()){
            if( map.containsKey("Musa")){
                map.put("Musa","MMMMMM");

            }
        }
        for(Map.Entry<String,String> entry : map.entrySet()){
            System.out.println("[Key] : " + entry.getKey() + " [Value] : " + entry.getValue());
        }
        System.out.println("=================================================");
        map.computeIfPresent("Test",(key,value)->"Love");
    }

    public static  void arrayElementCount( int [] inputArray){
        //1.Create The HashMap Object with elements of the inputArray as keys and  the occurrence a values
        //2.Iterate through the input array
        //3.check if the element of inputarray for its present in the map
        //4.If the element is already present inthe map increment its count by 1
        //5.if the element is not present in the map add the elemement gto the map with 1 as the value
        HashMap<Integer,Integer> map=new HashMap<>();
        for(int i:inputArray){

            if(map.containsKey(i)){
                   map.put(i,map.get(i)+1);
            }else{
                map.put(i,1);
            }
        }
        map.forEach((key, value) -> System.out.println("[Key] : " + key + " [Value] : " + value));
        System.out.println("=================================================");
        for(Map.Entry<Integer,Integer> entry : map.entrySet()){
            System.out.println("[Key] : " + entry.getKey() + " [Value] : " + entry.getValue());
        }
        System.out.println("================================================= e");
        HashMap<Integer,Integer> map2=new HashMap<>();
        map2.forEach((key,value)->{
            if(map2.containsKey(key)){
                map2.put(key,map2.get(key)+1);
            }else{
                map2.put(key,1);
            }
          }
        );
        map2.forEach((key, value) -> System.out.println("[Key] : " + key + " [Value] : " + value));

    }

}
