package com.learning;

import com.learning.AccConstants.Accounting;

public class TestLibra {
  public  static  void  main(String [] arc) {
    //givenEmptyLibraDataThenDecodeAndReturn();
    //givenNoBopThenDecodeAndReturn();
    givenNullLibraDataTagThenDecodeAndReturn2();
  }
  public static void givenNullLibraDataTagThenDecodeAndReturn2() {
    NBolXMLTransaction nBolXMLTransaction = new NBolXMLTransaction();
    nBolXMLTransaction.setTransactionType(Accounting.CREDIT_TRANSACTION);
    BalanceOfPayment balanceOfPayment = new BalanceOfPayment();
    nBolXMLTransaction.setBalanceOfPayment(balanceOfPayment);
    String libradata = TestReadXML.getDecodedLibraData7(nBolXMLTransaction);
  }
  public static void givenEmptyLibraDataThenDecodeAndReturn(){
    String libraDataraw = null;
    NBolXMLTransaction nBolXMLTransaction=new NBolXMLTransaction();
    //nBolXMLTransaction.setTransactionType(AccConstants.Accounting.DEBIT_TRANSACTION);
    nBolXMLTransaction.setTransactionType(AccConstants.Accounting.CREDIT_TRANSACTION);
    BalanceOfPayment balanceOfPayment=new BalanceOfPayment();
    balanceOfPayment.setLibraData(libraDataraw );
    nBolXMLTransaction.setBalanceOfPayment(balanceOfPayment);
    String libradata=TestReadXML.getDecodedLibraData5(nBolXMLTransaction);
    System.out.println("1<<<>>>"+libradata);
  // assertEquals("", libradata);

    System.out.println(Accounting.CREDIT_TRANSACTION);
    System.out.println(AccConstants.Accounting.CREDIT_TRANSACTION);
  }

  public static void givenNullLibraDataTagThenDecodeAndReturn(){
    NBolXMLTransaction nBolXMLTransaction=new NBolXMLTransaction();
    nBolXMLTransaction.setTransactionType(AccConstants.Accounting.CREDIT_TRANSACTION);
    BalanceOfPayment balanceOfPayment=new BalanceOfPayment();
    nBolXMLTransaction.setBalanceOfPayment(balanceOfPayment);
    String libradata=TestReadXML.getDecodedLibraData5(nBolXMLTransaction);
    System.out.println("3<<<>>>"+libradata);
  }
  public static void givenNoBopThenDecodeAndReturn(){
    NBolXMLTransaction nBolXMLTransaction=new NBolXMLTransaction();
    nBolXMLTransaction.setTransactionType(AccConstants.Accounting.CREDIT_TRANSACTION);
    String libradata=TestReadXML.getDecodedLibraData5(nBolXMLTransaction);
    System.out.println("2<<<>>>"+libradata);
  }
}
