package com.learning;

public class JsonStr {
    private String json;

    public JsonStr() {
    }

    public String getJson() {
        return json;
    }

    public void setJson(String json) {
        this.json = json;
    }
}
