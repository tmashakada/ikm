package com.learning;

import java.util.List;


import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

@XStreamAlias("bopHeader")
public class BopHeader extends BaseObject {

    private String reportingQualifier;
    private String flow;
    private String bopMulti;

    @XStreamImplicit
    @XStreamAlias("headerDetails")
    private List<HeaderDetails> headerDetails;

    public String getReportingQualifier() {
        return reportingQualifier;
    }

    public void setReportingQualifier(String reportingQualifier) {
        this.reportingQualifier = reportingQualifier;
    }

    public String getFlow() {
        return flow;
    }

    public void setFlow(String flow) {
        this.flow = flow;
    }

    public String getBopMulti() {
        return bopMulti;
    }

    public void setBopMulti(String bopMulti) {
        this.bopMulti = bopMulti;
    }

    public List<HeaderDetails> getHeaderDetails() {
        return headerDetails;
    }

    public void setHeaderDetails(List<HeaderDetails> headerDetails) {
        this.headerDetails = headerDetails;
    }


}
