package com.learning;


import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("thirdParty")
public class ThirdParty extends BaseObject {
    @XStreamAlias("indicatorT")
    public String indicatorT;
    @XStreamAlias("surname")
    public String surname;
    @XStreamAlias("name")
    public String name;
    @XStreamAlias("gender")
    public String gender;
    @XStreamAlias("dayOfBirth")
    public String dayOfBirth;
    @XStreamAlias("IDtype")
    public String IDtype;
    @XStreamAlias("IDnumber")
    public String IDnumber;
    @XStreamAlias("clientCustomNumbe1")
    public String clientCustomNumbe1;
    @XStreamAlias("passportCountry")
    public String passportCountry;
    @XStreamAlias("TPTAXNumber")
    public String TPTAXNumber;
    @XStreamAlias("TPVATNumber")
    public String TPVATNumber;
    @XStreamAlias("ccnNumbe1")
    public String ccnNumbe1;
    /*public Residential residential;
    public Postal postal;*/
    private Contact contact;

    public String tempResPermitNumber;
    public String passportNumber;
    public String legalEntityTPRegNum;
    public String legalEntityTPRegNumIdentityType;
    public String legalEntityTPName;
    @XStreamAlias("address")
    public Address address;
    public String contactEmail;
    public String contactFax;
    public String contactTelephone;
    private String contactName;
    private String contactSurname;
    private String ccnNumber;
    //only for mainframe, as address is keyword in mf
    private ThirdPartyAddress thirdPartyAddress;

    public String getLegalEntityTPName() {
        return legalEntityTPName;
    }

    public void setLegalEntityTPName(String legalEntityTPName) {
        this.legalEntityTPName = legalEntityTPName;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }


    public String getIDtype() {
        return IDtype;
    }

    public void setIDtype(String iDtype) {
        IDtype = iDtype;
    }

    public String getIDnumber() {
        return IDnumber;
    }

    public void setIDnumber(String iDnumber) {
        IDnumber = iDnumber;
    }

    public String getPassportCountry() {
        return passportCountry;
    }

    public void setPassportCountry(String passportCountry) {
        this.passportCountry = passportCountry;
    }

    public String getIndicatorT() {
        return indicatorT;
    }

    public void setIndicatorT(String indicatorT) {
        this.indicatorT = indicatorT;
    }

    public String getDayOfBirth() {
        return dayOfBirth;
    }

    public void setDayOfBirth(String dayOfBirth) {
        this.dayOfBirth = dayOfBirth;
    }

    public String getClientCustomNumbe1() {
        return clientCustomNumbe1;
    }

    public void setClientCustomNumbe1(String clientCustomNumbe1) {
        this.clientCustomNumbe1 = clientCustomNumbe1;
    }

    public String getTPTAXNumber() {
        return TPTAXNumber;
    }

    public void setTPTAXNumber(String tPTAXNumber) {
        TPTAXNumber = tPTAXNumber;
    }

    public String getTPVATNumber() {
        return TPVATNumber;
    }

    public void setTPVATNumber(String tPVATNumber) {
        TPVATNumber = tPVATNumber;
    }

    public String getCcnNumbe1() {
        return ccnNumbe1;
    }

    public void setCcnNumbe1(String ccnNumbe1) {
        this.ccnNumbe1 = ccnNumbe1;
    }

    public String getTempResPermitNumber() {
        return tempResPermitNumber;
    }

    public void setTempResPermitNumber(String tempResPermitNumber) {
        this.tempResPermitNumber = tempResPermitNumber;
    }

    public String getPassportNumber() {
        return passportNumber;
    }

    public void setPassportNumber(String passportNumber) {
        this.passportNumber = passportNumber;
    }

    public String getLegalEntityTPRegNum() {
        return legalEntityTPRegNum;
    }

    public void setLegalEntityTPRegNum(String legalEntityTPRegNum) {
        this.legalEntityTPRegNum = legalEntityTPRegNum;
    }

    public String getLegalEntityTPRegNumIdentityType() {
        return legalEntityTPRegNumIdentityType;
    }

    public void setLegalEntityTPRegNumIdentityType(String legalEntityTPRegNumIdentityType) {
        this.legalEntityTPRegNumIdentityType = legalEntityTPRegNumIdentityType;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public String getContactEmail() {
        return contactEmail;
    }

    public void setContactEmail(String contactEmail) {
        this.contactEmail = contactEmail;
    }

    public String getContactFax() {
        return contactFax;
    }

    public void setContactFax(String contactFax) {
        this.contactFax = contactFax;
    }

    public String getContactTelephone() {
        return contactTelephone;
    }

    public void setContactTelephone(String contactTelephone) {
        this.contactTelephone = contactTelephone;
    }

    public String getCcnNumber() {
        return ccnNumber;
    }

    public void setCcnNumber(String ccnNumber) {
        this.ccnNumber = ccnNumber;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public String getContactSurname() {
        return contactSurname;
    }

    public void setContactSurname(String contactSurname) {
        this.contactSurname = contactSurname;
    }

    public ThirdPartyAddress getThirdPartyAddress() {
        return thirdPartyAddress;
    }

    public void setThirdPartyAddress(ThirdPartyAddress thirdPartyAddress) {
        this.thirdPartyAddress = thirdPartyAddress;
    }

    public Contact getContact() {
        return contact;
    }

    public void setContact(Contact contact) {
        this.contact = contact;
    }



}
