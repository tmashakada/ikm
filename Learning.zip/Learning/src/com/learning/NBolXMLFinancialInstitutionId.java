package com.learning;


import com.thoughtworks.xstream.annotations.XStreamAlias;

/**
 *
 * @author Herman Sheppard
 *
 * XStream object wrapping for XML received from nBol.
 *
 */

@XStreamAlias("FinInstnId")
public class NBolXMLFinancialInstitutionId {

    @XStreamAlias("BIC")
    private String bic;

    @XStreamAlias("Nm")
    private String name;

    @XStreamAlias("PstlAdr")
    private NBolXMLPostalAddress postalAddress;

    public void setBic(String bic) {
        this.bic = bic;
    }

    public String getBic() {
        return bic;
    }

    public void setPostalAddress(NBolXMLPostalAddress postalAddress) {
        this.postalAddress = postalAddress;
    }

    public NBolXMLPostalAddress getPostalAddress() {
        return postalAddress;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

}
