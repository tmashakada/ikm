package com.learning;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class RemovingDuplicates {

  public static  void main(String [] args){
    List<String> duplicatesList= Arrays.asList("Java","Test","MM","Java","KK","Test");
    List<String> unique=duplicatesList.stream()
        .distinct()
        .collect(Collectors.toList());
    unique.forEach(System.out::println);
  }

}
