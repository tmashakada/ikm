package com.learning;

import com.thoughtworks.xstream.annotations.XStreamAlias;

/**
 *
 * @author Herman Sheppard
 *
 * XStream object wrapping for XML received from nBol.
 *
 */

@XStreamAlias("Id")
public class NBolXMLAccountOwnerId {

    @XStreamAlias("Id")
    private String id;

    @XStreamAlias("Key")
    private String key;

    public void setId(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getKey() {
        return key;
    }
}

