package com.learning;


import com.thoughtworks.xstream.annotations.XStreamAlias;

//@XStreamAlias("excon")
public class Excon extends BaseObject {

    private String indicatorE;
    private String exconNumber;
    private String exconDealer;
    private String exconDate;
    private String sarbRef;
    private String sarbAuthAppNumber;
    private String sarbAuthRefNumber;

    public String getIndicatorE() {
        return indicatorE;
    }
    public void setIndicatorE(String indicatorE) {
        this.indicatorE = indicatorE;
    }
    public String getExconNumber() {
        return exconNumber;
    }
    public void setExconNumber(String exconNumber) {
        this.exconNumber = exconNumber;
    }
    public String getExconDealer() {
        return exconDealer;
    }
    public void setExconDealer(String exconDealer) {
        this.exconDealer = exconDealer;
    }
    public String getExconDate() {
        return exconDate;
    }
    public void setExconDate(String exconDate) {
        this.exconDate = exconDate;
    }
    public String getSarbRef() {
        return sarbRef;
    }
    public void setSarbRef(String sarbRef) {
        this.sarbRef = sarbRef;
    }
    public String getSarbAuthAppNumber() {
        return sarbAuthAppNumber;
    }
    public void setSarbAuthAppNumber(String sarbAuthAppNumber) {
        this.sarbAuthAppNumber = sarbAuthAppNumber;
    }
    public String getSarbAuthRefNumber() {
        return sarbAuthRefNumber;
    }
    public void setSarbAuthRefNumber(String sarbAuthRefNumber) {
        this.sarbAuthRefNumber = sarbAuthRefNumber;
    }
}
