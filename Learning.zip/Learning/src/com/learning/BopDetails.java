package com.learning;

import java.util.List;





import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

@XStreamAlias("bopDetails")
public class BopDetails extends BaseObject {

    private String transactionType;
    private String transactionSubType;
    private String transactionCategory;
    private String bopCategory;
    private String bopSubCategory;
    private String bopSequenceNumber;
    private String sectionOfRulings;
    private String principleAmount;
    private String loanReferenceNumber;
    private String otherBopDetails;
    private String exconNumber;
    private String exconDate;
    private String exconDealer;
    private String sarbAuthRefNumber;

    private String locationCountry;
    private String ccnNumber;

    private Excon excon;

    @XStreamImplicit
    @XStreamAlias("bopSubDetails")
    private List<BopSubDetails> bopSubDetails;

    @XStreamAlias("TAXNumber")
    private String taxNumber;

    @XStreamAlias("VATNumber")
    private String vatNumber;

    @XStreamAlias("sarbDispensation")
    private String sarbDispensation;

    @XStreamAlias("moneyTransferAgent")
    private String moneyTransferAgent;

    @XStreamAlias("TAXCleranceIndicator")
    private String taxCleranceIndicator;

    @XStreamAlias("TAXClearanceRef")
    private String taxClearanceRef;

    @XStreamAlias("loan")
    private Loan loan;

    @XStreamAlias("adHoc")
    public AdHoc adHoc;

    @XStreamAlias("thirdParty")
    private ThirdParty thirdParty;

    private String loanTenor;
    private String loanInterestType;
    private String loanInterestRate;
    private String exconSTDBank;
    private String STBankInternalExternal;
    @XStreamAlias("SARBReference")
    private String sarbReference;
    private String bopSubDetailsIndicator;
    private String bopSubDetailsCount;
    private String totalBopSubDetailsCount;
    @XStreamAlias("ReversalTrnRefNumber")
    private String reversalTrnRefNumber;
    @XStreamAlias("ReversalSequence")
    private String reversalSequence;
    private String categoryDescription;
    private String internalExternal;

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public String getTransactionCategory() {
        return transactionCategory;
    }

    public void setTransactionCategory(String transactionCategory) {
        this.transactionCategory = transactionCategory;
    }

    public String getBopCategory() {
        return bopCategory;
    }

    public void setBopCategory(String bopCategory) {
        this.bopCategory = bopCategory;
    }

    public String getBopSubCategory() {
        return bopSubCategory;
    }

    public void setBopSubCategory(String bopSubCategory) {
        this.bopSubCategory = bopSubCategory;
    }

    public String getBopSequenceNumber() {
        return bopSequenceNumber;
    }

    public void setBopSequenceNumber(String bopSequenceNumber) {
        this.bopSequenceNumber = bopSequenceNumber;
    }

    public String getSectionOfRulings() {
        return sectionOfRulings;
    }

    public void setSectionOfRulings(String sectionOfRulings) {
        this.sectionOfRulings = sectionOfRulings;
    }

    public String getPrincipleAmount() {
        return principleAmount;
    }

    public void setPrincipleAmount(String principleAmount) {
        this.principleAmount = principleAmount;
    }

    public String getLoanReferenceNumber() {
        return loanReferenceNumber;
    }

    public void setLoanReferenceNumber(String loanReferenceNumber) {
        this.loanReferenceNumber = loanReferenceNumber;
    }

    public String getOtherBopDetails() {
        return otherBopDetails;
    }

    public void setOtherBopDetails(String otherBopDetails) {
        this.otherBopDetails = otherBopDetails;
    }

    public String getExconNumber() {
        return exconNumber;
    }

    public void setExconNumber(String exconNumber) {
        this.exconNumber = exconNumber;
    }

    public String getExconDate() {
        return exconDate;
    }

    public void setExconDate(String exconDate) {
        this.exconDate = exconDate;
    }

    public String getExconDealer() {
        return exconDealer;
    }

    public void setExconDealer(String exconDealer) {
        this.exconDealer = exconDealer;
    }

    public List<BopSubDetails> getBopSubDetails() {
        return bopSubDetails;
    }

    public void setBopSubDetails(List<BopSubDetails> bopSubDetails) {
        this.bopSubDetails = bopSubDetails;
    }

    public String getTransactionSubType() {
        return transactionSubType;
    }

    public void setTransactionSubType(String transactionSubType) {
        this.transactionSubType = transactionSubType;
    }

    public String getLocationCountry() {
        return locationCountry;
    }

    public void setLocationCountry(String locationCountry) {
        this.locationCountry = locationCountry;
    }

    public Excon getExcon() {
        return excon;
    }

    public void setExcon(Excon excon) {
        this.excon = excon;
    }

    public String getCcnNumber() {
        return ccnNumber;
    }

    public void setCcnNumber(String ccnNumber) {
        this.ccnNumber = ccnNumber;
    }

    public String getTaxNumber() {
        return taxNumber;
    }

    public void setTaxNumber(String taxNumber) {
        this.taxNumber = taxNumber;
    }

    public String getVatNumber() {
        return vatNumber;
    }

    public void setVatNumber(String vatNumber) {
        this.vatNumber = vatNumber;
    }

    public Loan getLoan() {
        return loan;
    }

    public void setLoan(Loan loan) {
        this.loan = loan;
    }

    public ThirdParty getThirdParty() {
        return thirdParty;
    }

    public void setThirdParty(ThirdParty thirdParty) {
        this.thirdParty = thirdParty;
    }

    public String getSarbDispensation() {
        return sarbDispensation;
    }

    public void setSarbDispensation(String sarbDispensation) {
        this.sarbDispensation = sarbDispensation;
    }

    public String getMoneyTransferAgent() {
        return moneyTransferAgent;
    }

    public void setMoneyTransferAgent(String moneyTransferAgent) {
        this.moneyTransferAgent = moneyTransferAgent;
    }

    public AdHoc getAdHoc() {
        return adHoc;
    }

    public void setAdHoc(AdHoc adHoc) {
        this.adHoc = adHoc;
    }

    public String getTaxCleranceIndicator() {
        return taxCleranceIndicator;
    }

    public void setTaxCleranceIndicator(String taxCleranceIndicator) {
        this.taxCleranceIndicator = taxCleranceIndicator;
    }

    public String getTaxClearanceRef() {
        return taxClearanceRef;
    }

    public void setTaxClearanceRef(String taxClearanceRef) {
        this.taxClearanceRef = taxClearanceRef;
    }

    public String getLoanTenor() {
        return loanTenor;
    }

    public void setLoanTenor(String loanTenor) {
        this.loanTenor = loanTenor;
    }

    public String getLoanInterestType() {
        return loanInterestType;
    }

    public void setLoanInterestType(String loanInterestType) {
        this.loanInterestType = loanInterestType;
    }

    public String getLoanInterestRate() {
        return loanInterestRate;
    }

    public void setLoanInterestRate(String loanInterestRate) {
        this.loanInterestRate = loanInterestRate;
    }

    public String getExconSTDBank() {
        return exconSTDBank;
    }

    public void setExconSTDBank(String exconSTDBank) {
        this.exconSTDBank = exconSTDBank;
    }

    public String getSTBankInternalExternal() {
        return STBankInternalExternal;
    }

    public void setSTBankInternalExternal(String sTBankInternalExternal) {
        STBankInternalExternal = sTBankInternalExternal;
    }

    public String getInternalExternal() {
        return internalExternal;
    }

    public void setInternalExternal(String internalExternal) {
        this.internalExternal = internalExternal;
    }

    public String getSarbReference() {
        return sarbReference;
    }

    public void setSarbReference(String sarbReference) {
        this.sarbReference = sarbReference;
    }

    public String getBopSubDetailsIndicator() {
        return bopSubDetailsIndicator;
    }

    public void setBopSubDetailsIndicator(String bopSubDetailsIndicator) {
        this.bopSubDetailsIndicator = bopSubDetailsIndicator;
    }

    public String getBopSubDetailsCount() {
        return bopSubDetailsCount;
    }

    public void setBopSubDetailsCount(String bopSubDetailsCount) {
        this.bopSubDetailsCount = bopSubDetailsCount;
    }

    public String getTotalBopSubDetailsCount() {
        return totalBopSubDetailsCount;
    }

    public void setTotalBopSubDetailsCount(String totalBopSubDetailsCount) {
        this.totalBopSubDetailsCount = totalBopSubDetailsCount;
    }

    public String getReversalTrnRefNumber() {
        return reversalTrnRefNumber;
    }

    public void setReversalTrnRefNumber(String reversalTrnRefNumber) {
        this.reversalTrnRefNumber = reversalTrnRefNumber;
    }

    public String getReversalSequence() {
        return reversalSequence;
    }

    public void setReversalSequence(String reversalSequence) {
        this.reversalSequence = reversalSequence;
    }

    public String getCategoryDescription() {
        return categoryDescription;
    }

    public void setCategoryDescription(String categoryDescription) {
        this.categoryDescription = categoryDescription;
    }

    public String getSarbAuthRefNumber() {
        return sarbAuthRefNumber;
    }
    public void setSarbAuthRefNumber(String sarbAuthRefNumber) {
        this.sarbAuthRefNumber = sarbAuthRefNumber;
    }
}
