package com.learning;


import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("bopSubDetails")
public class BopSubDetails extends BaseObject{

    private String bopSubSequenceNumber;
    private String mrnUcrNumber;
    private String mrnUcrAmount;
    private String transportDocumentNumber;
    private String ccnNumber;
    private String errorCode;
    private String errorMessage;
    private String ivsReference;
    private String mrnConfirmationReference;
    private String noMRNOnIVS;
    private String childPageNumber;
    private String parentPageNumber;
    private String bopDetailsSequenceNumber;

    public String getBopSubSequenceNumber() {
        return bopSubSequenceNumber;
    }
    public void setBopSubSequenceNumber(String bopSubSequenceNumber) {
        this.bopSubSequenceNumber = bopSubSequenceNumber;
    }
    public String getMrnUcrNumber() {
        return mrnUcrNumber;
    }
    public void setMrnUcrNumber(String mrnUcrNumber) {
        this.mrnUcrNumber = mrnUcrNumber;
    }
    public String getMrnUcrAmount() {
        return mrnUcrAmount;
    }
    public void setMrnUcrAmount(String mrnUcrAmount) {
        this.mrnUcrAmount = mrnUcrAmount;
    }
    public String getTransportDocumentNumber() {
        return transportDocumentNumber;
    }
    public void setTransportDocumentNumber(String transportDocumentNumber) {
        this.transportDocumentNumber = transportDocumentNumber;
    }
    public String getCcnNumber() {
        return ccnNumber;
    }
    public void setCcnNumber(String ccnNumber) {
        this.ccnNumber = ccnNumber;
    }
    public String getErrorCode() {
        return errorCode;
    }
    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }
    public String getErrorMessage() {
        return errorMessage;
    }
    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }
    public String getIvsReference() {
        return ivsReference;
    }
    public void setIvsReference(String ivsReference) {
        this.ivsReference = ivsReference;
    }
    public String getMrnConfirmationReference() {
        return mrnConfirmationReference;
    }
    public void setMrnConfirmationReference(String mrnConfirmationReference) {
        this.mrnConfirmationReference = mrnConfirmationReference;
    }
    public String getNoMRNOnIVS() {
        return noMRNOnIVS;
    }
    public void setNoMRNOnIVS(String noMRNOnIVS) {
        this.noMRNOnIVS = noMRNOnIVS;
    }
    public String getChildPageNumber() {
        return childPageNumber;
    }
    public void setChildPageNumber(String childPageNumber) {
        this.childPageNumber = childPageNumber;
    }
    public String getParentPageNumber() {
        return parentPageNumber;
    }
    public void setParentPageNumber(String parentPageNumber) {
        this.parentPageNumber = parentPageNumber;
    }
    public String getBopDetailsSequenceNumber() {
        return bopDetailsSequenceNumber;
    }
    public void setBopDetailsSequenceNumber(String bopDetailsSequenceNumber) {
        this.bopDetailsSequenceNumber = bopDetailsSequenceNumber;
    }
}
