package com.learning;

public class StpCutOffService {

  private static EEProductEntityUtil EEProductEntityUtils;

  private static final String RTGS = "RTGS";
  //EEProductEntityUtils.PRODUCT_AT


  public static String getProductCode(String productCode) {
     return EEProductEntityUtils.MODULE_INTR.equalsIgnoreCase(productCode) ?EEProductEntityUtils.PRODUCT_AT :productCode ;
   // return EEProductEntityUtils.MODULE_INTR.equalsIgnoreCase(productCode) ?productCode :EEProductEntityUtils.PRODUCT_AT ;
  }
  public static boolean transactionTypeRTGS(String country, String currency, String beneficiaryCountryCode) {

    String itemName = country + currency + RTGS;

    if (!country.equalsIgnoreCase(beneficiaryCountryCode)) {
      System.out.println("Test boolean   ");
      return false;
    }

   // final DataMaster dm = supportDataDao.getDataMaster(
      //  country,
       // CommonConstants.DAO.DataMaster.TABLE_47,
      //  itemName,
      //  false
   // );

   // if (dm != null) {
     // return true;
   // }
    return false;
  }
  public static String getItemName(String unitCode, String productCode){
    if(EEProductEntityUtils.PRODUCT_IT.equalsIgnoreCase(productCode)){
      return unitCode;
    }

    return unitCode + "_" + productCode;
  }

}
