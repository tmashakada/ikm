package com.learning;


import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("ContactPerson")
public class NBolXMLContactPerson extends BaseObject{
    @XStreamAlias("Name")
    private String name;

    @XStreamAlias("SurName")
    private String surname;

    @XStreamAlias("Email")
    private String email;

    @XStreamAlias("Fax")
    private String fax;

    @XStreamAlias("Telephone")
    private String telephone;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }


}
