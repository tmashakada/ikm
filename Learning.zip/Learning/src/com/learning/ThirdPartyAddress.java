package com.learning;


import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("thirdPartyAddress")
public class ThirdPartyAddress extends BaseObject {

    @XStreamAlias("postal")
    private Postal postal;

    @XStreamAlias("residential")
    private Residential residental;

    public Postal getPostal() {
        return postal;
    }
    public void setPostal(Postal postal) {
        this.postal = postal;
    }
    public Residential getResidental() {
        return residental;
    }
    public void setResidental(Residential residental) {
        this.residental = residental;
    }


}

