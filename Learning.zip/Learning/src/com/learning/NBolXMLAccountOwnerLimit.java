package com.learning;

import com.thoughtworks.xstream.annotations.XStreamAlias;

/**
 *
 * @author Herman Sheppard
 *
 * XStream object wrapping for XML received from nBol.
 *
 */

@XStreamAlias("Lmt")
public class NBolXMLAccountOwnerLimit {

    @XStreamAlias("Amt")
    private String amount;

    @XStreamAlias("Ccy")
    private String currencyCode;

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getAmount() {
        return amount;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

}

