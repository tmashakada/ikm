package com.learning;


import java.util.List;

//import com.standardbank.bridge.core.model.BaseObject;
//import com.standardbank.bridge.core.model.ResponsePayloadOnlyError;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

/**
 *
 * @author Herman Sheppard
 *
 * XStream object wrapping for XML received from nBol.
 *
 */

@XStreamAlias("Batch")
public class NBolXMLWrapperXStream extends BaseObject {

    private static final long serialVersionUID = -3800917823750014319L;

    private String BatchNumber;

    private String SendersBIC;

    @XStreamImplicit(itemFieldName="Instr")
    private List<NBolXMLInstruction> Instr;


    private String messageType;

    private String countryISO;

    private String trackingId;

    private String correlationId;

    private String sourceSystem;

    private ResponsePayloadOnlyError payload;

    @XStreamAlias("DocSightingRequestId")
    private String docSightingRequestId;

    public NBolXMLWrapperXStream() {
        super();

    }

    public void setBatchNumber(String batchNumber) {
        this.BatchNumber = batchNumber;
    }


    public String getBatchNumber() {
        return BatchNumber;
    }



    public void setSendersBIC(String senderBIC) {
        this.SendersBIC = senderBIC;
    }



    public String getSendersBIC() {
        return SendersBIC;
    }

    public void setInstr(List<NBolXMLInstruction> instr) {
        Instr = instr;
    }

    public List<NBolXMLInstruction> getInstr() {
        return Instr;
    }

    public void setMessageType(String messageType) {
        this.messageType = messageType;
    }

    public String getMessageType() {
        return messageType;
    }

    public void setCountryISO(String countryISO) {
        this.countryISO = countryISO;
    }

    public String getCountryISO() {
        return countryISO;
    }

    public void setPayload(ResponsePayloadOnlyError payload) {
        this.payload = payload;
    }

    public ResponsePayloadOnlyError getPayload() {
        return payload;
    }

    public void setTrackingId(String trackingId) {
        this.trackingId = trackingId;
    }

    public String getTrackingId() {
        return trackingId;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    public String getCorrelationId() {
        return correlationId;
    }

    public void setSourceSystem(String sourceSystem) {
        this.sourceSystem = sourceSystem;
    }

    public String getSourceSystem() {
        return sourceSystem;
    }

    public String getDocSightingRequestId() {
        return docSightingRequestId;
    }

    public void setDocSightingRequestId(String docSightingRequestId) {
        this.docSightingRequestId = docSightingRequestId;
    }




}
