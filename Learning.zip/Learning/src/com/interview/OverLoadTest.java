package com.interview;

public class OverLoadTest {
		public  int accountEntries(int accountNumber){
				
				return accountNumber;
		}
  private   int accountEntries2(int accountNumber, boolean error){
				
				return accountNumber;
		}
		public  double accountEntries(double accountNumber){
				
				return accountNumber;
		}
		
		public void accountEntries3(String  accountNumber){
		
		
		}
		private void accountEntries(int accN, boolean error){
		
		
		}
	protected Long accountEntries(String  accountNumber){
			
			return null;
	}
}
