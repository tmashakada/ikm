package com.interview;

public class TestString {
		
		public static void main(String[] args) {
				String e = "1";
				System.out.println(("1" != e) ? "True" : "False");
				int a = 0;
				System.out.println((~a == 0) ? "True" : "False");
				Double d = null;
				System.out.println((d instanceof Double) ? "True" : "False");
				int c = 0;
				System.out.println((c == ++c) ? "True" : "False");
				boolean b= false;
				System.out.println((b == true) ? "True" : "False");
				
		}
}