package com.interview;

public class TestDir {
		public static void main(String[] args){
				System.out.println("dDate.getDayOfMonth()+dDate.getMonthValue()");
		}
}
