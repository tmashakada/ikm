package com.interview;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;

public class Question108 {
		
		public static void main(String[] args) throws ParseException {
				Date aDate = null;
				aDate = new SimpleDateFormat("yyyy-mm-dd").parse("2021-01-15");
				Calendar aCalender = Calendar.getInstance();
				aCalender.setTime(aDate);
				System.out.println(aCalender.get(aCalender.DAY_OF_MONTH) + " ," + aCalender.get(aCalender.MONTH));
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyy-MM-dd");
				LocalDate dDate=LocalDate.parse("2021-01-15",formatter);
				System.out.println(dDate.getDayOfMonth()+" ,"+dDate.getMonthValue());
		}
}
