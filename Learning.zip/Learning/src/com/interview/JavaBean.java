package com.interview;

public class JavaBean {
		private Prescription prescription;
		private boolean prescriptionDispensed;
		
		public Prescription getPrescription() {
				return prescription;
		}
		
		public void setPrescription(Prescription prescription) {
				this.prescription = prescription;
		}
		
		public boolean isPrescriptionDispensed() {
				return prescriptionDispensed;
		}
		
		public void setPrescriptionDispensed(boolean prescriptionDispensed) {
				this.prescriptionDispensed = prescriptionDispensed;
		}
}
