package com.interview;

import java.math.BigDecimal;

public class JavaClass {
		static	public void main(String... args){
				//public static void main(String ss[]){
				String a =null;
				if(a==null || a.length()<10){
						System.out.println("nnnnn");
				}
				
		}
		
		BigDecimal findRoot(BigDecimal n){
				
				return n;
		}
		private static BigDecimal findRoot2(BigDecimal n){
				
				return n;
		}
		synchronized BigDecimal findRoot3(BigDecimal n){
				
				return n;
		}

}
