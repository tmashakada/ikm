package com.interview;

public class ThisSuper {
/**
	* Can we have this () and super () together?
	* No, you cannot have both this() and super() in a single constructor.
	*/
/**
	* If we include “this()” or “super()” inside the constructor,
	* it must be the first statement inside it. “this()” and “super()” cannot be used inside the same constructor,
	* as both cannot be executed at once (both cannot be the first statement).
	* “this” can be passed as an argument in the method and constructor calls.
	*/
}
