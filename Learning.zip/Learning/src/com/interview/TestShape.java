package com.interview;

public class TestShape {
		
		public static void main(String[] args) {
				Shape shape = new QuardLiteral();
				QuardLiteral quardLiteral = new QuardLiteral();
				
				shape =quardLiteral;
				//Triangle t=(Triangle)quardLiteral;
				
		//	Shape tt=(Triangle)shape;
		//	Triangle ttt=(Triangle) shape;
				//shape=quardLiteral;
				
				Triangle t=(Triangle)shape;
		}
}