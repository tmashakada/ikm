package com.interview;

public class TestInvoice {
		public static void main(String[] args){
				Invoice invoice=new Invoice();
		//		System.out.println((SalesInvoice)Invoice.formatId("1234"));
				Invoice invoices=new SalesInvoice();
						System.out.println(Invoice.formatId("1234"));
						//Output 1234_Invoice
				System.out.println(invoice.formatId("1234"));
				//1234_Invoice
				
		}
}
