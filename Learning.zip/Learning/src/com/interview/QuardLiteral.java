package com.interview;

public class QuardLiteral extends Shape {

}
