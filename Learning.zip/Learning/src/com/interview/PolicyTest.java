package com.interview;

public class PolicyTest {
		public static void main(String[] args){
				Policy [] policies={new Policy("Smith","Internal")
								,new Policy("Doe","External")
								,new Policy("John","Internal")
							};
				for(Policy policy:policies){
						if(policy.getType().equals("Internal")){
								System.out.println(policy.getName());
							
						}
				}
				
		}
}
