package com.interview;

import java.util.Formatter;

public class FormatTest {
		public static void main(String[] args){
				String a="A";
				String b="B";
				String strNull=null;
				StringBuilder buffer=new StringBuilder("C");
				Formatter formatter=new Formatter(buffer);
				formatter.format("%s%S",a,b);
				System.out.println("Line 1 "+formatter);
				formatter.format("%-2s",b);
				System.out.println("Line2 "+formatter);
				formatter.format("%b",strNull);
				System.out.println("Line 3 "+formatter);
		}
}
