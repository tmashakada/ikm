package com.interview.myexception;

public class TestMyException {
		public static void main(String[] args){
				MyException 	myException=new 	MyException("nn");
				myException.getMessage();
				System.out.println(myException.getMessage());
				MyException2 myException2=new MyException2("nnn");
				myException2.getLocalisedMessage();
				System.out.println(	myException2.getLocalisedMessage());
		}
	
}
