package com.interview.myexception;

import java.math.BigDecimal;

public class TestMethodSignature {
		synchronized  BigDecimal findRoot(){
				
				return null;
		}
}
