package com.interview.myexception;

public class MyException2  extends  RuntimeException{
		
		public MyException2(String message) {
				super(message);
		}
		public String getLocalisedMessage(){
				
				return "My Exception";
		}
}
