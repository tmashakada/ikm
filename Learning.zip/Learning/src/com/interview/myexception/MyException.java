package com.interview.myexception;

public class MyException {
		
		public MyException(String message) {
		}
		public String getMessage(){
				
				return "My Exception";
		}
}
