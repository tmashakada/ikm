package com.interview;

import java.util.Arrays;

public class ComparableTest  implements Comparable<ComparableTest>{
		private String  value;
		
	
		public ComparableTest(String newValue) {
				this.value =  newValue;
		}
		
		@Override
		public int compareTo(ComparableTest testObject) {
		//	return Integer.parseInt(testObject.toString())-Integer.parseInt(value);
				//return Integer.parseUnsignedInt(testObject.toString())-Integer.parseUnsignedInt(value);
		//		return Integer.parseInt(value)-Integer.parseInt(testObject.toString());
				return Integer.parseInt(value)+ Integer.parseInt(testObject.toString());
		}
		public static void main(String[] args){
				ComparableTest[] ct={new ComparableTest("3"),
								                 new ComparableTest("2"),
								                  new ComparableTest("4"),
								                 new ComparableTest("1")};
				Arrays.sort(ct);
				for(ComparableTest c:ct){
						System.out.print(c +" ");
				}
		}
}
