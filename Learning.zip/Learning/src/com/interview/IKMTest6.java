package com.interview;

import java.util.SortedSet;
import java.util.TreeSet;

public class IKMTest6 {
		public static void main(String[] args){
				SortedSet<ElementK> s=new TreeSet<ElementK>();
								s.add(new ElementK(15));
				    s.add(new ElementK(10));
			     	s.add(new ElementK(25));
				s.add(new ElementK(10));
				System.out.println(s.first()+" "+s.size());
		}
}
