package com.interview;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OfficeParamsList {
		public static void main(String[] args){
				List<Map<List<Integer>,List<String>>> officeParamsList=new ArrayList<>();
				Map<List<Integer>,List<String>> officeParamMap=new HashMap<>();
				officeParamsList.add(null);
				officeParamsList.add(officeParamMap);
				officeParamsList.add(new HashMap<List<Integer>,List<String>>());
				officeParamsList.forEach(e->System.out.print(e+" "));
		}
}
