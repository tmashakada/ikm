package com.interview;

import java.io.IOException;

public class JavaSeSnippet {
		public static void main(String[] args) throws IOException {
				Integer number1=new Integer(1);
			Integer number2=number1;
				//The value of a is increased by just 1
			number1+=1;
				System.out.println(number1);
				System.out.println(number2);
		}
}
