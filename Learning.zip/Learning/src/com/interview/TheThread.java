package com.interview;

public class TheThread {
		public static void main(String[] args) {
				Runnable r=()-> System.out.println("Hi");
				new Thread(r).start();
		}
		
	
}
