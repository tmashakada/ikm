package com.interview;

public class TestPassBytValue {
		/**
		Java passes all primitive data types by value.
		This means that a copy is made, so that it cannot be modified.
		When passing Java objects, you're passing an object reference,
		which makes it possible to modify the object's member variables.
			
			Primitive data types such as string, number, null, undefined, and boolean,
			are passed by value while non-primitive data types such as objects,
			arrays, and functions are passed by reference in Javascript.
			
			**/
		
}
