package com.interview;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FilterReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class BufferedReaderTest {
		public static void main(String[] args){
				BufferedReader in=null;
				PrintWriter  out=null;
				try{
						out= new PrintWriter(new FileWriter("tt"));
						in=new BufferedReader(new FileReader("tt")) ;
						Stream.of("RED","BLUE","GREEN").forEach(out::println);
						out.flush();
					//	System.out.println(in.lines());
					//	in.readLine().for
					//in.lines().forEach(System.out::println);
						//in.stream
						List<String> i=in.lines().collect(Collectors.toList());
						i.stream().forEach(System.out::println);
				}catch (IOException e){
				
				}
		}
}
