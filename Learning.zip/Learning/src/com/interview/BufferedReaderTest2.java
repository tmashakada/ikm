package com.interview;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.InputStreamReader;

public class BufferedReaderTest2 {
		public static void main(String[] args) throws FileNotFoundException {
				//BufferedReader br=new BufferedReader(new InputStreamReader("Input.dat"));
				//BufferedReader br=new BufferedReader(new File("Input.dat"))
				 FileReader fr=new FileReader("Input.dat");
				BufferedReader br=new BufferedReader(new FileReader("Input.dat"));
				//BufferedReader br2=new BufferedReader("Input.dat");
		}
}
