package com.interview;

public class ObjectEq {
		
		public static void main(String[] args) {
				Long I = new Long(1234);
				Long I1 = I;
				if(I==I1)
						System.out.println("Egual Objects");
				else
						System.out.println("Not Egual Objects");
				I++;
				if(I==I1)
						System.out.println("Egual Objects");
				else
						System.out.println("Not Egual Objects");
		}
}
