package com.interview;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Mars {
		public static void main(String[] args){
				List<String> names = Arrays.asList("Jupiter","Neptune","Mars","Earth");
				Map<Integer, List<String>> names_lenghts=names.stream().collect(Collectors.groupingBy(p->p.length()));
				names_lenghts.forEach((i,s)->System.out.println(i +"= "+s+" " ));
		}
}
