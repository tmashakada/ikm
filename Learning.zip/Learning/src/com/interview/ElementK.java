package com.interview;

public class ElementK implements  Comparable{
		int id;
		
		public ElementK(int id) {
				this.id = id;
		}
		public int compareTo(Object obj){
				ElementK e =(ElementK) obj;
				return this.id- e.id;
		}
		public String toString(){
				return ""+this.id;
		}
}
