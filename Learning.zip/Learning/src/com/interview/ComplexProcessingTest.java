package com.interview;

public class ComplexProcessingTest {
		public static void main(String[] args){
				 new ComplexProcessing().testExucte(1);
		}
}
