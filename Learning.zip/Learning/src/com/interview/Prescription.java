package com.interview;

public class Prescription {

}
