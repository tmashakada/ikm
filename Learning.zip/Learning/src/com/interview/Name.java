package com.interview;

public class Name {
		private  String first , last;
		
		public Name(String first, String last) {
				this.first = first;
				this.last = last;
		}
		
		public Name() {
		}
		@Override
		public String toString(){
				return first +" "+last	;	}
		public static  int compareByLastName(Name n1, Name n2){
				return n1.last.compareTo(n2.last);
		}
		
		
}
