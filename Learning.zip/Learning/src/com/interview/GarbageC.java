package com.interview;

public class GarbageC {
		/**
			1.Question garbage collection halts when an exception is thrown by the finalize method
		finalize() method gets called only once by GC, if an exception is thrown by finalizing method
		or the object revives itself from finalize(),
		the garbage collector will not call the finalize() method again.
		It's not guaranteed if the finalized method will be called or not, or when it will be called.
			
			=====
			Exceptions in finalize() method:
			
			If any exception occurs in finalize() method,
			it is ignored by Garbage Collector, and finalize() method is not executed.
			
			==
			
			When the finalize () method gets called?
			Finalize() is the method of Object class. This method is called just before an object is garbage collected.
			finalize() method overrides to dispose system resources,
			perform clean-up activities and minimize memory leaks.
			**/
		
		
}
