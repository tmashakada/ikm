package com.interview.interfaces;

import com.sun.jdi.connect.spi.Connection;

public  abstract  class RelationDBOperation implements DatabaseOperation{

	public abstract  String getData(String query);
		public abstract void executeProcedure(String procedureName);
}
