package com.interview.interfaces;

public abstract class Parent implements MyInterface {
  public abstract  void method1();
}
