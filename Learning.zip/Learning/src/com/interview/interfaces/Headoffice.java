package com.interview.interfaces;

public  class Headoffice implements Company{
		

		public  String getSAddress(Long id) {
				return null;
		}
		
		@Override
		public String getSAddress(String companyName) {
				return null;
		}
		
		@Override
		public String getPhoneNumber() {
				return Company.super.getPhoneNumber();
		}
}
