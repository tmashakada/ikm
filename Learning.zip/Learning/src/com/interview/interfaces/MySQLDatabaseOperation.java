package com.interview.interfaces;

import com.sun.jdi.connect.spi.Connection;
import java.util.List;

public abstract class MySQLDatabaseOperation implements DatabaseOperation {
		public String getData(String query){
				
				return query;
		}
		public void executeProcedure(String procedureName){
				System.out.println("Do nothing  nn");
		}
		
		public Connection getConnection(){
				
				return null;
		}
		abstract   void batchExecution(List<String> batchqry);
		
}
