package com.interview.interfaces;

import com.sun.jdi.connect.spi.Connection;

public interface DatabaseOperation {
 String getData(String query);
	default  void executeProcedure(String procedureName){
			System.out.println("Do nothing");
	}
	Connection getConnection();
}
