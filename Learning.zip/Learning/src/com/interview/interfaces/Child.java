package com.interview.interfaces;

public abstract class Child extends  Parent implements MyInterface{
		
		@Override
		public void method1() {
		
		}
}
