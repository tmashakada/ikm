package com.interview.interfaces;

public interface MyInterface {
 void method1();
	static  void method2(){};
}
