package com.interview.interfaces;

public interface Company {
		public String getSAddress(String companyName);
		default  public String getPhoneNumber(){
				return "555-1212";
		}
}
