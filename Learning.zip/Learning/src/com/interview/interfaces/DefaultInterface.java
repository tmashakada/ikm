package com.interview.interfaces;

public interface DefaultInterface {
		default  void printName(){
				System.out.println("HHhhhhhh");
		}
}
