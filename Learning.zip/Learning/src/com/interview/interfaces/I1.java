package com.interview.interfaces;

public interface I1 {
		String name="N1";
		String s1="S1";
}
