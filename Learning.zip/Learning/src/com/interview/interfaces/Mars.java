package com.interview.interfaces;

public class Mars {

}
