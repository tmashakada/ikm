package com.interview.interfaces;

public class DefaultInterfaceImp  implements DefaultInterface {
		
		public void printName() {
				System.out.println("bbbb");
		}
		
		public static void main(String[] args) {
				DefaultInterfaceImp nn=new DefaultInterfaceImp();
				nn.printName();
				
		}
}
