package com.interview.interfaces;

public interface I2 extends I1{
		String name="N2";
}
