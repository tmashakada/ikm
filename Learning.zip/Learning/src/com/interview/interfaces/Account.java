package com.interview.interfaces;

import java.math.BigDecimal;

public interface Account {
//BigDecimal balance=BigDecimal.ZERO;
BigDecimal balance= new BigDecimal(0.00);
}
