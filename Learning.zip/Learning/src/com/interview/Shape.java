package com.interview;

public class Shape {

}
