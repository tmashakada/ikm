package com.interview;

public class Triangle  extends Shape{

}
