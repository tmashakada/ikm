package com.interview;

import java.util.Arrays;
import java.util.List;

public class TestName {
		public static void main(String[] args) {
				Name n1=new Name("Harry","Homeowner");
				Name n2=new Name("Paul","Painter");
				Name n3=new Name("Jane","Doe");
				List<Name>  nameList= Arrays.asList(n1,n2,n3);
				nameList.sort(Name::compareByLastName);
				nameList.forEach(System.out::println);
				
			
		}
}
