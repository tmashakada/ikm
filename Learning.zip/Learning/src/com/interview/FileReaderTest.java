package com.interview;

import java.io.BufferedReader;
import java.io.*;

public class FileReaderTest {
		//C:\personalprojects\testfile
		public static void main(String[] args) throws Exception
		{
				File file = new File("C:\\personalprojects\\testfile\\test.txt");
		}
		public void bufferedReader(File file) throws IOException {
				BufferedReader br				= new BufferedReader(new FileReader(file));
				
				// Declaring a string variable
				String st;
				// Condition holds true till
				// there is character in a string
				while ((st = br.readLine()) != null)
						
						// Print the string
						System.out.println(st);
		}
		
		public void fileReader() throws IOException {
				// Passing the path to the file as a parameter
				FileReader fr = new FileReader("C:\\Users\\pankaj\\Desktop\\test.txt");
				
				// Declaring loop variable
				int i;
				// Holds true till there is nothing to read
				while ((i = fr.read()) != -1)
						
						// Print all the content of a file
						System.out.print((char)i);
		}
		
}
