package com.interview;

public class JavaStandardQ {
		public static void main(String[] args) {
				int value =25;
				Integer before =value;
				System.out.println(before);
				Long after =++before==26?5:new Long(10);
				System.out.println(after.intValue());
				System.out.println(before.intValue());
				System.out.println(after.intValue()-before.intValue());
				
				
		}
}
