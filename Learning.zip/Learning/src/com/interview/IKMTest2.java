package com.interview;

public class IKMTest2 {
		void display(){
				System.out.println("Data ="+data);
		}
		int data;
		public static void main(String[] args) {
				int x=0;
				IKMTest2 nn=new IKMTest2();
				nn.display();
		}
}
