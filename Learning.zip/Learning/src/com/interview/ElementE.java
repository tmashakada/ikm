package com.interview;

public enum ElementE {
		HELIUM("He","Gas"),
		MAGNESIUM("Mg","SOLID");
		private String chemicalSymbol;
		private String nature;
		
		private ElementE(String newChemicalSymbol, String newNature) {
				chemicalSymbol =  newChemicalSymbol;
				nature = newNature;
		}
		public String chemicalSymbol(){
				return chemicalSymbol;
		}
		
		public String nature() {
				return nature;
		}
}
