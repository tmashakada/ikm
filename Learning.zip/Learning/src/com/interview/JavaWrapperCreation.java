package com.interview;

public class JavaWrapperCreation {
		
		public static void main(String[] args) {
				//	Integer i=Integer.parseUnsignedInt(4);
				Double d=Double.valueOf("17.569d");
				Boolean b=new Boolean("false");
	//			Character c=new Character('C');
				Float f=new Float(2.356);
				System.out.println(d+""+ b+"" + f);
		}
}