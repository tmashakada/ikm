package com.interview;

import java.io.IOException;

public class Question40 {
		public static void main(String[] args) throws IOException {
				/**
				In simple words, == checks if both objects point to the same memory location whereas
				equals() evaluates to the comparison of values in the objects.
					**/
				Long i=new Long(Long.MAX_VALUE);
				long j=Long.MAX_VALUE;
				long k=0xffff_ffff_ffff_ffffL;
				if(i.equals(j)){
						System.out.println("i is equal to j");
				}else{
						System.out.println("i is not equal to j");
				}
				if(j==k)
						System.out.println("J is equal to K");
				else
						System.out.println("j is not equal to K");
				}
		//  if(Long.compare(i,K)>0){
				
		
}
