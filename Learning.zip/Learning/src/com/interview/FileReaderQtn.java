package com.interview;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FilterInputStream;
import java.io.FilterReader;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.io.Reader;
import java.io.Writer;

public class FileReaderQtn {
		
		
		public static void main(String[] args) throws FileNotFoundException {
				FileInputStream fin = new FileInputStream("file.text");
				//	FileInputStream finnew=new FileInputStream("file.text");
				//BufferedReader br=new BufferedReader(finnew,"UTF_8");
				//	FileReader fr=new Reader("file.text");
				//Reader is abstract can not instantiated
				RandomAccessFile rf = new RandomAccessFile("file.text", "r");
				//FileInputStream fis=new FileInputStream("file.text");
				//		FileReader fr2=new FileReader(fis.toString());
				//OutputStream o=new OutputStream() ;
				//	FilterReader frr=new FilterReader();
				
				//			PrintWriter bbb=new PrintWriter();
				
		//		FilterInputStream nnn=new FilterInputStream();
		}
}
