package com.interview;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.io.Reader;
import java.util.Objects;
import java.util.Optional;

public class TestFile {
		
		public static void main(String[] args) throws IOException {
				Optional<String> f= Optional.of("file1.java");
				
				File f1=new File(f.get());
			//	InputStream iout=new 	InputStream(f1);
				InputStream iout=new FileInputStream(f1);
					//andomAccessFile rf=new RandomAccessFile(f1);
				Reader iuot=new FileReader(f1);
				FileOutputStream  ioute=new FileOutputStream(f1);
				
		};
		
		}
