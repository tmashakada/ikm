package com.interview;

public class BinaryOperatorQts {
		/**
			*
			* BinaryOperator is a functional interface,
			* which takes in two arguments of the same type and returns a result that is also of the same type.
			* This interface extends the BiFunction interface. This interface has two methods: minBy(Comparator<?
			*
			*
			* Java BiFunction - Examples
			*
			* javabydeveloper.com
			* https://javabydeveloper.com › Core Java
			* 05 Jul 2023 — In Java 8, BiFunction interface is a built in functional interface
			* which accepts two arguments and produces a results.
			*
			* What is the difference between binary operator and BiFunction?
			* The BinaryOperator takes two arguments of the same type and returns a result of the same type of its arguments.
			* The BiFunction takes two arguments of any type, and returns a result of any type
			*/
}
